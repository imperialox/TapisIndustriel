/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: animConfig
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\MainExeReel.h
*********************************************************************/

#ifndef MainExeReel_H
#define MainExeReel_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\MainExeReel.h
*********************************************************************/
