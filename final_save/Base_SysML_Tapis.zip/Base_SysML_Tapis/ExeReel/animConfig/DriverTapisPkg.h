/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: DriverTapisPkg
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\DriverTapisPkg.h
*********************************************************************/

#ifndef DriverTapisPkg_H
#define DriverTapisPkg_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include <oxf\event.h>
//## dependency _DESIGN
#include "_DESIGN.h"
//## auto_generated
class DriverTapis;

//## auto_generated
class IConnect;

//#[ ignore
#define evConnect_DriverTapisPkg_id 14801
//#]

//## package DriverTapisPkg


//#[ type AVANCER
#define AVANCER 1
//#]

//#[ type ARRETER
#define ARRETER 0
//#]

//#[ type RECULER
#define RECULER -1
//#]

//#[ type COTE_A
#define COTE_A 1
//#]

//#[ type COTE_B
#define COTE_B 0
//#]

//#[ type Bit
typedef unsigned  Bit;
//#]

//#[ type StructEntrees
typedef struct {
   unsigned int tampon1:4;
   Bit dca  :1;
   Bit dcb  :1;
   Bit deba :1;
   Bit mia  :1;
   unsigned int tampon2:4;
   Bit fina :1;
   Bit debb :1;
   Bit mib  :1;
   Bit finb :1;
   unsigned int tampon3:4;
   Bit debc :1;
   Bit finc :1;
   Bit versa:1;
   Bit versb:1;

} StructEntrees;
//#]

//#[ type StructSorties
typedef struct {
Bit mava:1;
Bit mara:1;
Bit mavb:1;
Bit marb:1;
Bit mavc:1;
Bit marc:1;
Bit ev  :1; //1 : position A/C  0 : position B/C
} StructSorties;
//#]

//#[ type Entrees
union Entrees {
   unsigned char Bytes[3];
   StructEntrees Valeurs;
};
//#]

//#[ type Sorties
union Sorties {
   unsigned char Bytes[1];
   StructSorties Valeurs;
};
//#]

//## event evConnect()
class evConnect : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedevConnect;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    evConnect();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedevConnect : virtual public AOMEvent {
    DECLARE_META_EVENT(evConnect)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\DriverTapisPkg.h
*********************************************************************/
