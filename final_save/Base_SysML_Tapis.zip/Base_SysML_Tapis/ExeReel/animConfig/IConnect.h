/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: IConnect
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\IConnect.h
*********************************************************************/

#ifndef IConnect_H
#define IConnect_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include "DriverTapisPkg.h"
//## package DriverTapisPkg

//## class IConnect
class IConnect {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedIConnect;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    IConnect();
    
    //## auto_generated
    virtual ~IConnect() = 0;
    
    ////    Operations    ////
    
    //## operation connectToMaquette(int,int)
    virtual bool connectToMaquette(int numPC, int numMaq) = 0;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedIConnect : virtual public AOMInstance {
    DECLARE_META(IConnect, OMAnimatedIConnect)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\IConnect.h
*********************************************************************/
