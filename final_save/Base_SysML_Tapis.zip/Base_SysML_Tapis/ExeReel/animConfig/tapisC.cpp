/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: tapisC
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\tapisC.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX

#define _OMSTATECHART_ANIMATED
//#]

//## auto_generated
#include "tapisC.h"
//#[ ignore
#define _DESIGN_tapisC_tapisC_SERIALIZE OM_NO_OP
//#]

//## package _DESIGN

//## class tapisC
//#[ ignore
tapisC::cmd_SP_C::cmd_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::cmd_SP_C::~cmd_SP_C() {
    cleanUpRelations();
}

void tapisC::cmd_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* tapisC::cmd_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* tapisC::cmd_SP_C::getOutBound() {
    return this;
}

void tapisC::cmd_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::cmd_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapisC::deb_SP_C::deb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::deb_SP_C::~deb_SP_C() {
    cleanUpRelations();
}

void tapisC::deb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapisC::deb_SP_C::connectTapisC(tapisC* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapisC::deb_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapisC::deb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::deb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapisC::versa_SP_C::versa_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::versa_SP_C::~versa_SP_C() {
    cleanUpRelations();
}

void tapisC::versa_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapisC::versa_SP_C::connectTapisC(tapisC* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapisC::versa_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapisC::versa_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::versa_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapisC::fin_SP_C::fin_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::fin_SP_C::~fin_SP_C() {
    cleanUpRelations();
}

void tapisC::fin_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapisC::fin_SP_C::connectTapisC(tapisC* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapisC::fin_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapisC::fin_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::fin_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapisC::versb_SP_C::versb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::versb_SP_C::~versb_SP_C() {
    cleanUpRelations();
}

void tapisC::versb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapisC::versb_SP_C::connectTapisC(tapisC* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapisC::versb_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapisC::versb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::versb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapisC::finb_SP_C::finb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::finb_SP_C::~finb_SP_C() {
    cleanUpRelations();
}

void tapisC::finb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapisC::finb_SP_C::connectTapisC(tapisC* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapisC::finb_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapisC::finb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::finb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapisC::fina_SP_C::fina_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapisC::fina_SP_C::~fina_SP_C() {
    cleanUpRelations();
}

void tapisC::fina_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapisC::fina_SP_C::connectTapisC(tapisC* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapisC::fina_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapisC::fina_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapisC::fina_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}
//#]

tapisC::tapisC(IOxfActive* theActiveContext) : cmd(0), deb(0), fin(0), fina(0), finb(0), versa(0), versb(0) {
    NOTIFY_REACTIVE_CONSTRUCTOR(tapisC, tapisC(), 0, _DESIGN_tapisC_tapisC_SERIALIZE);
    setActiveContext(theActiveContext, false);
    initRelations();
    initStatechart();
}

tapisC::~tapisC() {
    NOTIFY_DESTRUCTOR(~tapisC, true);
    cancelTimeouts();
}

//#[ ignore
void tapisC::SetValue(int data, void * pCaller) {
    if (pCaller == (void *)get_deb_SP()) {
        setDeb(data);
    }
    
    if (pCaller == (void *)get_versa_SP()) {
        setVersa(data);
    }
    
    if (pCaller == (void *)get_fin_SP()) {
        setFin(data);
    }
    
    if (pCaller == (void *)get_versb_SP()) {
        setVersb(data);
    }
    
    if (pCaller == (void *)get_finb_SP()) {
        setFinb(data);
    }
    
    if (pCaller == (void *)get_fina_SP()) {
        setFina(data);
    }
}

void tapisC::setCmd(int p_cmd) {
    if (cmd != p_cmd)  {
        cmd = p_cmd;
        FLOW_DATA_SEND(cmd, cmd_SP, SetValue, x2String);
    }
}

void tapisC::setDeb(int p_deb) {
    if (deb != p_deb) {
        deb = p_deb;
        FLOW_DATA_RECEIVE("deb", deb, x2String);
        GEN(chDeb);
    }
    
}

void tapisC::setFin(int p_fin) {
    if (fin != p_fin) {
        fin = p_fin;
        FLOW_DATA_RECEIVE("fin", fin, x2String);
        GEN(chFin);
    }
    
}

void tapisC::setFina(int p_fina) {
    if (fina != p_fina) {
        fina = p_fina;
        FLOW_DATA_RECEIVE("fina", fina, x2String);
        GEN(chFina);
    }
    
}

void tapisC::setFinb(int p_finb) {
    if (finb != p_finb) {
        finb = p_finb;
        FLOW_DATA_RECEIVE("finb", finb, x2String);
        GEN(chFinb);
    }
    
}

void tapisC::setVersa(int p_versa) {
    if (versa != p_versa) {
        versa = p_versa;
        FLOW_DATA_RECEIVE("versa", versa, x2String);
        GEN(chVersa);
    }
    
}

void tapisC::setVersb(int p_versb) {
    if (versb != p_versb) {
        versb = p_versb;
        FLOW_DATA_RECEIVE("versb", versb, x2String);
        GEN(chVersb);
    }
    
}
//#]

tapisC::cmd_SP_C* tapisC::getCmd_SP() const {
    return (tapisC::cmd_SP_C*) &cmd_SP;
}

tapisC::cmd_SP_C* tapisC::get_cmd_SP() const {
    return (tapisC::cmd_SP_C*) &cmd_SP;
}

tapisC::deb_SP_C* tapisC::getDeb_SP() const {
    return (tapisC::deb_SP_C*) &deb_SP;
}

tapisC::deb_SP_C* tapisC::get_deb_SP() const {
    return (tapisC::deb_SP_C*) &deb_SP;
}

tapisC::versa_SP_C* tapisC::getVersa_SP() const {
    return (tapisC::versa_SP_C*) &versa_SP;
}

tapisC::versa_SP_C* tapisC::get_versa_SP() const {
    return (tapisC::versa_SP_C*) &versa_SP;
}

tapisC::fin_SP_C* tapisC::getFin_SP() const {
    return (tapisC::fin_SP_C*) &fin_SP;
}

tapisC::fin_SP_C* tapisC::get_fin_SP() const {
    return (tapisC::fin_SP_C*) &fin_SP;
}

tapisC::versb_SP_C* tapisC::getVersb_SP() const {
    return (tapisC::versb_SP_C*) &versb_SP;
}

tapisC::versb_SP_C* tapisC::get_versb_SP() const {
    return (tapisC::versb_SP_C*) &versb_SP;
}

tapisC::finb_SP_C* tapisC::getFinb_SP() const {
    return (tapisC::finb_SP_C*) &finb_SP;
}

tapisC::finb_SP_C* tapisC::get_finb_SP() const {
    return (tapisC::finb_SP_C*) &finb_SP;
}

tapisC::fina_SP_C* tapisC::getFina_SP() const {
    return (tapisC::fina_SP_C*) &fina_SP;
}

tapisC::fina_SP_C* tapisC::get_fina_SP() const {
    return (tapisC::fina_SP_C*) &fina_SP;
}

int tapisC::getCmd() const {
    return cmd;
}

int tapisC::getDeb() const {
    return deb;
}

int tapisC::getFin() const {
    return fin;
}

int tapisC::getFina() const {
    return fina;
}

int tapisC::getFinb() const {
    return finb;
}

int tapisC::getVersa() const {
    return versa;
}

int tapisC::getVersb() const {
    return versb;
}

bool tapisC::startBehavior() {
    bool done = false;
    done = OMReactive::startBehavior();
    return done;
}

void tapisC::initRelations() {
    if (get_deb_SP() != NULL) {
        get_deb_SP()->connectTapisC(this);
    }
    if (get_versa_SP() != NULL) {
        get_versa_SP()->connectTapisC(this);
    }
    if (get_fin_SP() != NULL) {
        get_fin_SP()->connectTapisC(this);
    }
    if (get_versb_SP() != NULL) {
        get_versb_SP()->connectTapisC(this);
    }
    if (get_finb_SP() != NULL) {
        get_finb_SP()->connectTapisC(this);
    }
    if (get_fina_SP() != NULL) {
        get_fina_SP()->connectTapisC(this);
    }
}

void tapisC::initStatechart() {
    rootState_subState = OMNonState;
    rootState_active = OMNonState;
    rootState_timeout = NULL;
}

void tapisC::cancelTimeouts() {
    cancel(rootState_timeout);
}

bool tapisC::cancelTimeout(const IOxfTimeout* arg) {
    bool res = false;
    if(rootState_timeout == arg)
        {
            rootState_timeout = NULL;
            res = true;
        }
    return res;
}

void tapisC::rootState_entDef() {
    {
        NOTIFY_STATE_ENTERED("ROOT");
        NOTIFY_TRANSITION_STARTED("0");
        NOTIFY_STATE_ENTERED("ROOT.state_0");
        rootState_subState = state_0;
        rootState_active = state_0;
        NOTIFY_TRANSITION_TERMINATED("0");
    }
}

IOxfReactive::TakeEventStatus tapisC::rootState_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (rootState_active) {
        // State state_0
        case state_0:
        {
            if(IS_EVENT_TYPE_OF(chFina__DESIGN_id))
                {
                    //## transition 4 
                    if(fina==1)
                        {
                            NOTIFY_TRANSITION_STARTED("4");
                            NOTIFY_STATE_EXITED("ROOT.state_0");
                            //#[ transition 4 
                            setCmd(1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_4");
                            rootState_subState = state_4;
                            rootState_active = state_4;
                            NOTIFY_TRANSITION_TERMINATED("4");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(chFinb__DESIGN_id))
                {
                    //## transition 5 
                    if(finb==1)
                        {
                            NOTIFY_TRANSITION_STARTED("5");
                            NOTIFY_STATE_EXITED("ROOT.state_0");
                            //#[ transition 5 
                            setCmd(1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_4");
                            rootState_subState = state_4;
                            rootState_active = state_4;
                            NOTIFY_TRANSITION_TERMINATED("5");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_1
        case state_1:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == rootState_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("2");
                            cancel(rootState_timeout);
                            NOTIFY_STATE_EXITED("ROOT.state_1");
                            //#[ transition 2 
                            setCmd(-1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_3");
                            rootState_subState = state_3;
                            rootState_active = state_3;
                            NOTIFY_TRANSITION_TERMINATED("2");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_3
        case state_3:
        {
            if(IS_EVENT_TYPE_OF(chDeb__DESIGN_id))
                {
                    //## transition 3 
                    if(deb==1)
                        {
                            NOTIFY_TRANSITION_STARTED("3");
                            NOTIFY_STATE_EXITED("ROOT.state_3");
                            //#[ transition 3 
                            setCmd(0);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_0");
                            rootState_subState = state_0;
                            rootState_active = state_0;
                            NOTIFY_TRANSITION_TERMINATED("3");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_4
        case state_4:
        {
            if(IS_EVENT_TYPE_OF(chFin__DESIGN_id))
                {
                    //## transition 1 
                    if(fin==1)
                        {
                            NOTIFY_TRANSITION_STARTED("1");
                            NOTIFY_STATE_EXITED("ROOT.state_4");
                            //#[ transition 1 
                            setCmd(0);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_1");
                            rootState_subState = state_1;
                            rootState_active = state_1;
                            rootState_timeout = scheduleTimeout(3000, "ROOT.state_1");
                            NOTIFY_TRANSITION_TERMINATED("1");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        default:
            break;
    }
    return res;
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimatedtapisC::serializeAttributes(AOMSAttributes* aomsAttributes) const {
    aomsAttributes->addAttribute("cmd", x2String(myReal->cmd));
    aomsAttributes->addAttribute("deb", x2String(myReal->deb));
    aomsAttributes->addAttribute("fin", x2String(myReal->fin));
    aomsAttributes->addAttribute("versa", x2String(myReal->versa));
    aomsAttributes->addAttribute("versb", x2String(myReal->versb));
    aomsAttributes->addAttribute("finb", x2String(myReal->finb));
    aomsAttributes->addAttribute("fina", x2String(myReal->fina));
}

void OMAnimatedtapisC::serializeRelations(AOMSRelations* aomsRelations) const {
}

void OMAnimatedtapisC::rootState_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT");
    switch (myReal->rootState_subState) {
        case tapisC::state_0:
        {
            state_0_serializeStates(aomsState);
        }
        break;
        case tapisC::state_1:
        {
            state_1_serializeStates(aomsState);
        }
        break;
        case tapisC::state_3:
        {
            state_3_serializeStates(aomsState);
        }
        break;
        case tapisC::state_4:
        {
            state_4_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimatedtapisC::state_4_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_4");
}

void OMAnimatedtapisC::state_3_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_3");
}

void OMAnimatedtapisC::state_1_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_1");
}

void OMAnimatedtapisC::state_0_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_0");
}
//#]

IMPLEMENT_REACTIVE_META_P(tapisC, _DESIGN, _DESIGN, false, OMAnimatedtapisC)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\tapisC.cpp
*********************************************************************/
