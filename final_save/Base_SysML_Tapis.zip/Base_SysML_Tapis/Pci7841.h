///////////////////////////////////////////////////////////////////////////////
//
//      Name   :    PCI7841.H (This header file is only for Win95/Win98
//      Purpose:    cPCI/PCI-7841 Driver Include file
//      Version:    Gamma - 1
//      Date   :    1999/12/15
//      Author :    chuhwa
//      Copyright 1999 ADLink Technology 	
//      
//      Modified:   
//        1999/12/15  Rewritting for convenient using (Beta-4 to Gamma-1)
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __PCI7841_H__
#define __PCI7841_H__

#include "typedef.h"

//  Card initialization and configuration functions
#if defined(__cplusplus)
extern "C"
{
#endif

WORD _stdcall GetDriverVersion(void);
long _stdcall CanOpenDriver(long card, long port);
long _stdcall CanCloseDriver(long handle);
long _stdcall CanConfigPort(long handle, PORT_STRUCT *PortStruct);
long _stdcall CanGetPortStatus(long handle, PORT_STATUS *PortStatus);
long _stdcall CanGetPortConfig(long handle, PORT_STRUCT *PortStruct);
long _stdcall CanDetectBaudrate(long handle, long miliSecs);
void _stdcall CanGetReceiveEvent(long handle,HANDLE *hevent);
long _stdcall CanGetRcvCnt(long handle);
long _stdcall CanInstallEvent(long handle, long index, HANDLE hEvent);

//  use for cPCI-7841
long _stdcall  CanGetLedStatus(long handle, long index);
void _stdcall CanSetLedStatus(long handle, long index, long mode);
//  CAN layer functions
long _stdcall CanEnableReceive(long handle);
long _stdcall CanDisableReceive(long handle);
long _stdcall CanSendMsg(long handle, CAN_PACKET *packet);
long _stdcall CanRcvMsg(long handle, CAN_PACKET *packet);

//  CAN layer status control
void _stdcall CanClearOverrun(long handle);
void _stdcall CanClearRxBuffer(long handle);
void _stdcall CanClearTxBuffer(long handle);
BYTE _stdcall CanGetArbitrationLostBit(long handle);
BYTE _stdcall CanGetErrorCode(long handle);
BYTE _stdcall CanGetErrorWarningLimit(long handle);
void _stdcall CanSetErrorWarningLimit(long handle, BYTE limit);
BYTE _stdcall CanGetRxErrorCount(long handle);
BYTE _stdcall CanGetTxErrorCount(long handle);
int _stdcall CanSetTxErrorCount(long handle, BYTE value);
BYTE _stdcall CanGetIntStatusReg(long handle);

BYTE _stdcall _7841_Read(long handle, long offset);
void _stdcall _7841_Write(long handle, long offset, BYTE data);

#if defined(__cplusplus)
}
#endif

#endif

