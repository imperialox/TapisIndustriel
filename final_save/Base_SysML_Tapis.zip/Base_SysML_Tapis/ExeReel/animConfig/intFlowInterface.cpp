/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: intFlowInterface
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\intFlowInterface.cpp
*********************************************************************/

//## auto_generated
#include "intFlowInterface.h"
//#[ ignore
//## package FlowPortInterfaces

//## ignore
intFlowInterface::intFlowInterface() {
}

intFlowInterface::~intFlowInterface() {
}
//#]

/*********************************************************************
	File Path	: ExeReel\animConfig\intFlowInterface.cpp
*********************************************************************/
