/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: IConnect
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\IConnect.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "IConnect.h"
//#[ ignore
#define DriverTapisPkg_IConnect_connectToMaquette_SERIALIZE \
    aomsmethod->addAttribute("numPC", x2String(numPC));\
    aomsmethod->addAttribute("numMaq", x2String(numMaq));
#define DriverTapisPkg_IConnect_IConnect_SERIALIZE OM_NO_OP
//#]

//## package DriverTapisPkg

//## class IConnect
IConnect::IConnect() {
    NOTIFY_CONSTRUCTOR(IConnect, IConnect(), 0, DriverTapisPkg_IConnect_IConnect_SERIALIZE);
}

IConnect::~IConnect() {
    NOTIFY_DESTRUCTOR(~IConnect, true);
}

#ifdef _OMINSTRUMENT
IMPLEMENT_META_P(IConnect, DriverTapisPkg, DriverTapisPkg, false, OMAnimatedIConnect)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\IConnect.cpp
*********************************************************************/
