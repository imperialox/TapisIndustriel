/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: FlowPortInterfaces
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\FlowPortInterfaces.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "FlowPortInterfaces.h"
//## auto_generated
#include "intFlowInterface.h"
//## package FlowPortInterfaces


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(FlowPortInterfaces, FlowPortInterfaces)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\FlowPortInterfaces.cpp
*********************************************************************/
