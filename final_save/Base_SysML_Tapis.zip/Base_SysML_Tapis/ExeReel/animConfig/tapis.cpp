/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: tapis
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\tapis.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX

#define _OMSTATECHART_ANIMATED
//#]

//## auto_generated
#include "tapis.h"
//#[ ignore
#define _DESIGN_tapis_tapis_SERIALIZE OM_NO_OP
//#]

//## package _DESIGN

//## class tapis
//#[ ignore
tapis::cmd_SP_C::cmd_SP_C() : _p_(0) {
}

tapis::cmd_SP_C::~cmd_SP_C() {
    cleanUpRelations();
}

void tapis::cmd_SP_C::SetValue(int data, void * pCaller) {
    
    for(int i = 0 ; i < itsIntFlowInterface.getCount() ; i++)
    {
        itsIntFlowInterface[i]->SetValue(data,pCaller);
        if(i < itsIntFlowInterface.getCount() - 1)
        {
            FLOW_DATA_POP
        }
    }
    
}

intFlowInterface* tapis::cmd_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* tapis::cmd_SP_C::getOutBound() {
    return this;
}

intFlowInterface* tapis::cmd_SP_C::getItsIntFlowInterfaceAt(int i) const {
    return itsIntFlowInterface.getAt(i);
}

void tapis::cmd_SP_C::addItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.add(p_intFlowInterface);
}

void tapis::cmd_SP_C::removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.remove(p_intFlowInterface);
}

void tapis::cmd_SP_C::clearItsIntFlowInterface() {
    itsIntFlowInterface.removeAll();
}

int tapis::cmd_SP_C::findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const {
    return itsIntFlowInterface.find(p_intFlowInterface);
}

void tapis::cmd_SP_C::cleanUpRelations() {
    {
        itsIntFlowInterface.removeAll();
    }
}

tapis::deb_SP_C::deb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapis::deb_SP_C::~deb_SP_C() {
    cleanUpRelations();
}

void tapis::deb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapis::deb_SP_C::connectTapis(tapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapis::deb_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapis::deb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapis::deb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapis::vers_SP_C::vers_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapis::vers_SP_C::~vers_SP_C() {
    cleanUpRelations();
}

void tapis::vers_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapis::vers_SP_C::connectTapis(tapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapis::vers_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapis::vers_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapis::vers_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapis::fin_SP_C::fin_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapis::fin_SP_C::~fin_SP_C() {
    cleanUpRelations();
}

void tapis::fin_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapis::fin_SP_C::connectTapis(tapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapis::fin_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapis::fin_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapis::fin_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapis::debc_SP_C::debc_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapis::debc_SP_C::~debc_SP_C() {
    cleanUpRelations();
}

void tapis::debc_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapis::debc_SP_C::connectTapis(tapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapis::debc_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapis::debc_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapis::debc_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

tapis::dc_SP_C::dc_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

tapis::dc_SP_C::~dc_SP_C() {
    cleanUpRelations();
}

void tapis::dc_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void tapis::dc_SP_C::connectTapis(tapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* tapis::dc_SP_C::getItsIntFlowInterface() {
    return this;
}

void tapis::dc_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void tapis::dc_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}
//#]

tapis::tapis(IOxfActive* theActiveContext) : cmd(0), dc(0), deb(0), debc(0), fin(0), vers(0) {
    NOTIFY_REACTIVE_CONSTRUCTOR(tapis, tapis(), 0, _DESIGN_tapis_tapis_SERIALIZE);
    setActiveContext(theActiveContext, false);
    initRelations();
    initStatechart();
}

tapis::~tapis() {
    NOTIFY_DESTRUCTOR(~tapis, true);
}

//#[ ignore
void tapis::SetValue(int data, void * pCaller) {
    if (pCaller == (void *)get_deb_SP()) {
        setDeb(data);
    }
    
    if (pCaller == (void *)get_vers_SP()) {
        setVers(data);
    }
    
    if (pCaller == (void *)get_fin_SP()) {
        setFin(data);
    }
    
    if (pCaller == (void *)get_debc_SP()) {
        setDebc(data);
    }
    
    if (pCaller == (void *)get_dc_SP()) {
        setDc(data);
    }
}

void tapis::setCmd(int p_cmd) {
    if (cmd != p_cmd)  {
        cmd = p_cmd;
        FLOW_DATA_SEND(cmd, cmd_SP, SetValue, x2String);
    }
}

void tapis::setDc(int p_dc) {
    if (dc != p_dc) {
        dc = p_dc;
        FLOW_DATA_RECEIVE("dc", dc, x2String);
        GEN(chDc);
    }
    
}

void tapis::setDeb(int p_deb) {
    if (deb != p_deb) {
        deb = p_deb;
        FLOW_DATA_RECEIVE("deb", deb, x2String);
        GEN(chDeb);
    }
    
}

void tapis::setDebc(int p_debc) {
    if (debc != p_debc) {
        debc = p_debc;
        FLOW_DATA_RECEIVE("debc", debc, x2String);
        GEN(chDebc);
    }
    
}

void tapis::setFin(int p_fin) {
    if (fin != p_fin) {
        fin = p_fin;
        FLOW_DATA_RECEIVE("fin", fin, x2String);
        GEN(chFin);
    }
    
}

void tapis::setVers(int p_vers) {
    if (vers != p_vers) {
        vers = p_vers;
        FLOW_DATA_RECEIVE("vers", vers, x2String);
        GEN(chVers);
    }
    
}
//#]

tapis::cmd_SP_C* tapis::getCmd_SP() const {
    return (tapis::cmd_SP_C*) &cmd_SP;
}

tapis::cmd_SP_C* tapis::get_cmd_SP() const {
    return (tapis::cmd_SP_C*) &cmd_SP;
}

tapis::deb_SP_C* tapis::getDeb_SP() const {
    return (tapis::deb_SP_C*) &deb_SP;
}

tapis::deb_SP_C* tapis::get_deb_SP() const {
    return (tapis::deb_SP_C*) &deb_SP;
}

tapis::vers_SP_C* tapis::getVers_SP() const {
    return (tapis::vers_SP_C*) &vers_SP;
}

tapis::vers_SP_C* tapis::get_vers_SP() const {
    return (tapis::vers_SP_C*) &vers_SP;
}

tapis::fin_SP_C* tapis::getFin_SP() const {
    return (tapis::fin_SP_C*) &fin_SP;
}

tapis::fin_SP_C* tapis::get_fin_SP() const {
    return (tapis::fin_SP_C*) &fin_SP;
}

tapis::debc_SP_C* tapis::getDebc_SP() const {
    return (tapis::debc_SP_C*) &debc_SP;
}

tapis::debc_SP_C* tapis::get_debc_SP() const {
    return (tapis::debc_SP_C*) &debc_SP;
}

tapis::dc_SP_C* tapis::getDc_SP() const {
    return (tapis::dc_SP_C*) &dc_SP;
}

tapis::dc_SP_C* tapis::get_dc_SP() const {
    return (tapis::dc_SP_C*) &dc_SP;
}

int tapis::getCmd() const {
    return cmd;
}

int tapis::getDc() const {
    return dc;
}

int tapis::getDeb() const {
    return deb;
}

int tapis::getDebc() const {
    return debc;
}

int tapis::getFin() const {
    return fin;
}

int tapis::getVers() const {
    return vers;
}

bool tapis::startBehavior() {
    bool done = false;
    done = OMReactive::startBehavior();
    return done;
}

void tapis::initRelations() {
    if (get_deb_SP() != NULL) {
        get_deb_SP()->connectTapis(this);
    }
    if (get_vers_SP() != NULL) {
        get_vers_SP()->connectTapis(this);
    }
    if (get_fin_SP() != NULL) {
        get_fin_SP()->connectTapis(this);
    }
    if (get_debc_SP() != NULL) {
        get_debc_SP()->connectTapis(this);
    }
    if (get_dc_SP() != NULL) {
        get_dc_SP()->connectTapis(this);
    }
}

void tapis::initStatechart() {
    rootState_subState = OMNonState;
    rootState_active = OMNonState;
}

void tapis::rootState_entDef() {
    {
        NOTIFY_STATE_ENTERED("ROOT");
        NOTIFY_TRANSITION_STARTED("0");
        NOTIFY_STATE_ENTERED("ROOT.state_3");
        rootState_subState = state_3;
        rootState_active = state_3;
        NOTIFY_TRANSITION_TERMINATED("0");
    }
}

IOxfReactive::TakeEventStatus tapis::rootState_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (rootState_active) {
        // State state_0
        case state_0:
        {
            if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    //## transition 1 
                    if(deb==1)
                        {
                            NOTIFY_TRANSITION_STARTED("1");
                            popNullTransition();
                            NOTIFY_STATE_EXITED("ROOT.state_0");
                            //#[ transition 1 
                            setCmd(1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_1");
                            rootState_subState = state_1;
                            rootState_active = state_1;
                            NOTIFY_TRANSITION_TERMINATED("1");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_1
        case state_1:
        {
            if(IS_EVENT_TYPE_OF(chFin__DESIGN_id))
                {
                    //## transition 2 
                    if(fin==1)
                        {
                            NOTIFY_TRANSITION_STARTED("2");
                            NOTIFY_STATE_EXITED("ROOT.state_1");
                            //#[ transition 2 
                            setCmd(0);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_2");
                            rootState_subState = state_2;
                            rootState_active = state_2;
                            NOTIFY_TRANSITION_TERMINATED("2");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_2
        case state_2:
        {
            if(IS_EVENT_TYPE_OF(chDebc__DESIGN_id))
                {
                    //## transition 3 
                    if(debc==1)
                        {
                            NOTIFY_TRANSITION_STARTED("3");
                            NOTIFY_STATE_EXITED("ROOT.state_2");
                            //#[ transition 3 
                            setCmd(-1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_4");
                            rootState_subState = state_4;
                            rootState_active = state_4;
                            NOTIFY_TRANSITION_TERMINATED("3");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_3
        case state_3:
        {
            if(IS_EVENT_TYPE_OF(chDc__DESIGN_id))
                {
                    //## transition 4 
                    if(dc==1)
                        {
                            NOTIFY_TRANSITION_STARTED("4");
                            NOTIFY_STATE_EXITED("ROOT.state_3");
                            NOTIFY_STATE_ENTERED("ROOT.state_0");
                            pushNullTransition();
                            rootState_subState = state_0;
                            rootState_active = state_0;
                            NOTIFY_TRANSITION_TERMINATED("4");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_4
        case state_4:
        {
            if(IS_EVENT_TYPE_OF(chDeb__DESIGN_id))
                {
                    //## transition 5 
                    if(deb==1)
                        {
                            NOTIFY_TRANSITION_STARTED("5");
                            NOTIFY_STATE_EXITED("ROOT.state_4");
                            //#[ transition 5 
                            setCmd(0);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_3");
                            rootState_subState = state_3;
                            rootState_active = state_3;
                            NOTIFY_TRANSITION_TERMINATED("5");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        default:
            break;
    }
    return res;
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimatedtapis::serializeAttributes(AOMSAttributes* aomsAttributes) const {
    aomsAttributes->addAttribute("cmd", x2String(myReal->cmd));
    aomsAttributes->addAttribute("deb", x2String(myReal->deb));
    aomsAttributes->addAttribute("vers", x2String(myReal->vers));
    aomsAttributes->addAttribute("fin", x2String(myReal->fin));
    aomsAttributes->addAttribute("debc", x2String(myReal->debc));
    aomsAttributes->addAttribute("dc", x2String(myReal->dc));
}

void OMAnimatedtapis::serializeRelations(AOMSRelations* aomsRelations) const {
}

void OMAnimatedtapis::rootState_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT");
    switch (myReal->rootState_subState) {
        case tapis::state_0:
        {
            state_0_serializeStates(aomsState);
        }
        break;
        case tapis::state_1:
        {
            state_1_serializeStates(aomsState);
        }
        break;
        case tapis::state_2:
        {
            state_2_serializeStates(aomsState);
        }
        break;
        case tapis::state_3:
        {
            state_3_serializeStates(aomsState);
        }
        break;
        case tapis::state_4:
        {
            state_4_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimatedtapis::state_4_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_4");
}

void OMAnimatedtapis::state_3_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_3");
}

void OMAnimatedtapis::state_2_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_2");
}

void OMAnimatedtapis::state_1_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_1");
}

void OMAnimatedtapis::state_0_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_0");
}
//#]

IMPLEMENT_REACTIVE_META_P(tapis, _DESIGN, _DESIGN, false, OMAnimatedtapis)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\tapis.cpp
*********************************************************************/
