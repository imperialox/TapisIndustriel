/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: FlowPortInterfaces
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\FlowPortInterfaces.h
*********************************************************************/

#ifndef FlowPortInterfaces_H
#define FlowPortInterfaces_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
class intFlowInterface;

//## package FlowPortInterfaces



#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\FlowPortInterfaces.h
*********************************************************************/
