/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: DriverTapis
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\DriverTapis.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX

#define _OMSTATECHART_ANIMATED
//#]

//## auto_generated
#include "DriverTapis.h"
//#[ ignore
#define DriverTapisPkg_DriverTapis_connectToMaquette_SERIALIZE \
    aomsmethod->addAttribute("numPC", x2String(numPC));\
    aomsmethod->addAttribute("numMaq", x2String(numMaq));
#define DriverTapisPkg_DriverTapis_DriverTapis_SERIALIZE OM_NO_OP

#define DriverTapisPkg_DriverTapis_init_can_SERIALIZE aomsmethod->addAttribute("id", x2String(id));

#define DriverTapisPkg_DriverTapis_readCapteurs_SERIALIZE OM_NO_OP

#define DriverTapisPkg_DriverTapis_recv_mess_SERIALIZE aomsmethod->addAttribute("entrees", x2String(entrees));

#define DriverTapisPkg_DriverTapis_sendCmd_SERIALIZE OM_NO_OP

#define DriverTapisPkg_DriverTapis_send_mess_SERIALIZE aomsmethod->addAttribute("sorties", UNKNOWN2STRING(sorties));
//#]

//## package DriverTapisPkg

//## class DriverTapis
//#[ ignore
DriverTapis::connect_C::connect_C() : _p_(0) {
    itsIConnect = NULL;
}

DriverTapis::connect_C::~connect_C() {
    cleanUpRelations();
}

void DriverTapis::connect_C::connectDriverTapis(DriverTapis* part) {
    setItsIConnect(part);
    
}

bool DriverTapis::connect_C::connectToMaquette(int numPC, int numMaq) {
    bool res = false;
    if (itsIConnect != NULL) {
        res = itsIConnect->connectToMaquette(numPC,numMaq);
    }
    return res;
}

IConnect* DriverTapis::connect_C::getItsIConnect() {
    return this;
}

void DriverTapis::connect_C::setItsIConnect(IConnect* p_IConnect) {
    itsIConnect = p_IConnect;
}

void DriverTapis::connect_C::cleanUpRelations() {
    if(itsIConnect != NULL)
        {
            itsIConnect = NULL;
        }
}

DriverTapis::cmdA_SP_C::cmdA_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::cmdA_SP_C::~cmdA_SP_C() {
    cleanUpRelations();
}

void DriverTapis::cmdA_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void DriverTapis::cmdA_SP_C::connectDriverTapis(DriverTapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* DriverTapis::cmdA_SP_C::getItsIntFlowInterface() {
    return this;
}

void DriverTapis::cmdA_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::cmdA_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::deba_SP_C::deba_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::deba_SP_C::~deba_SP_C() {
    cleanUpRelations();
}

void DriverTapis::deba_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::deba_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::deba_SP_C::getOutBound() {
    return this;
}

void DriverTapis::deba_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::deba_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::versa_SP_C::versa_SP_C() : _p_(0) {
}

DriverTapis::versa_SP_C::~versa_SP_C() {
    cleanUpRelations();
}

void DriverTapis::versa_SP_C::SetValue(int data, void * pCaller) {
    
    for(int i = 0 ; i < itsIntFlowInterface.getCount() ; i++)
    {
        itsIntFlowInterface[i]->SetValue(data,pCaller);
        if(i < itsIntFlowInterface.getCount() - 1)
        {
            FLOW_DATA_POP
        }
    }
    
}

intFlowInterface* DriverTapis::versa_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::versa_SP_C::getOutBound() {
    return this;
}

intFlowInterface* DriverTapis::versa_SP_C::getItsIntFlowInterfaceAt(int i) const {
    return itsIntFlowInterface.getAt(i);
}

void DriverTapis::versa_SP_C::addItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.add(p_intFlowInterface);
}

void DriverTapis::versa_SP_C::removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.remove(p_intFlowInterface);
}

void DriverTapis::versa_SP_C::clearItsIntFlowInterface() {
    itsIntFlowInterface.removeAll();
}

int DriverTapis::versa_SP_C::findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const {
    return itsIntFlowInterface.find(p_intFlowInterface);
}

void DriverTapis::versa_SP_C::cleanUpRelations() {
    {
        itsIntFlowInterface.removeAll();
    }
}

DriverTapis::fina_SP_C::fina_SP_C() : _p_(0) {
}

DriverTapis::fina_SP_C::~fina_SP_C() {
    cleanUpRelations();
}

void DriverTapis::fina_SP_C::SetValue(int data, void * pCaller) {
    
    for(int i = 0 ; i < itsIntFlowInterface.getCount() ; i++)
    {
        itsIntFlowInterface[i]->SetValue(data,pCaller);
        if(i < itsIntFlowInterface.getCount() - 1)
        {
            FLOW_DATA_POP
        }
    }
    
}

intFlowInterface* DriverTapis::fina_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::fina_SP_C::getOutBound() {
    return this;
}

intFlowInterface* DriverTapis::fina_SP_C::getItsIntFlowInterfaceAt(int i) const {
    return itsIntFlowInterface.getAt(i);
}

void DriverTapis::fina_SP_C::addItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.add(p_intFlowInterface);
}

void DriverTapis::fina_SP_C::removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.remove(p_intFlowInterface);
}

void DriverTapis::fina_SP_C::clearItsIntFlowInterface() {
    itsIntFlowInterface.removeAll();
}

int DriverTapis::fina_SP_C::findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const {
    return itsIntFlowInterface.find(p_intFlowInterface);
}

void DriverTapis::fina_SP_C::cleanUpRelations() {
    {
        itsIntFlowInterface.removeAll();
    }
}

DriverTapis::cmdB_SP_C::cmdB_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::cmdB_SP_C::~cmdB_SP_C() {
    cleanUpRelations();
}

void DriverTapis::cmdB_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void DriverTapis::cmdB_SP_C::connectDriverTapis(DriverTapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* DriverTapis::cmdB_SP_C::getItsIntFlowInterface() {
    return this;
}

void DriverTapis::cmdB_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::cmdB_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::debb_SP_C::debb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::debb_SP_C::~debb_SP_C() {
    cleanUpRelations();
}

void DriverTapis::debb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::debb_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::debb_SP_C::getOutBound() {
    return this;
}

void DriverTapis::debb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::debb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::versb_SP_C::versb_SP_C() : _p_(0) {
}

DriverTapis::versb_SP_C::~versb_SP_C() {
    cleanUpRelations();
}

void DriverTapis::versb_SP_C::SetValue(int data, void * pCaller) {
    
    for(int i = 0 ; i < itsIntFlowInterface.getCount() ; i++)
    {
        itsIntFlowInterface[i]->SetValue(data,pCaller);
        if(i < itsIntFlowInterface.getCount() - 1)
        {
            FLOW_DATA_POP
        }
    }
    
}

intFlowInterface* DriverTapis::versb_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::versb_SP_C::getOutBound() {
    return this;
}

intFlowInterface* DriverTapis::versb_SP_C::getItsIntFlowInterfaceAt(int i) const {
    return itsIntFlowInterface.getAt(i);
}

void DriverTapis::versb_SP_C::addItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.add(p_intFlowInterface);
}

void DriverTapis::versb_SP_C::removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.remove(p_intFlowInterface);
}

void DriverTapis::versb_SP_C::clearItsIntFlowInterface() {
    itsIntFlowInterface.removeAll();
}

int DriverTapis::versb_SP_C::findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const {
    return itsIntFlowInterface.find(p_intFlowInterface);
}

void DriverTapis::versb_SP_C::cleanUpRelations() {
    {
        itsIntFlowInterface.removeAll();
    }
}

DriverTapis::finb_SP_C::finb_SP_C() : _p_(0) {
}

DriverTapis::finb_SP_C::~finb_SP_C() {
    cleanUpRelations();
}

void DriverTapis::finb_SP_C::SetValue(int data, void * pCaller) {
    
    for(int i = 0 ; i < itsIntFlowInterface.getCount() ; i++)
    {
        itsIntFlowInterface[i]->SetValue(data,pCaller);
        if(i < itsIntFlowInterface.getCount() - 1)
        {
            FLOW_DATA_POP
        }
    }
    
}

intFlowInterface* DriverTapis::finb_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::finb_SP_C::getOutBound() {
    return this;
}

intFlowInterface* DriverTapis::finb_SP_C::getItsIntFlowInterfaceAt(int i) const {
    return itsIntFlowInterface.getAt(i);
}

void DriverTapis::finb_SP_C::addItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.add(p_intFlowInterface);
}

void DriverTapis::finb_SP_C::removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.remove(p_intFlowInterface);
}

void DriverTapis::finb_SP_C::clearItsIntFlowInterface() {
    itsIntFlowInterface.removeAll();
}

int DriverTapis::finb_SP_C::findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const {
    return itsIntFlowInterface.find(p_intFlowInterface);
}

void DriverTapis::finb_SP_C::cleanUpRelations() {
    {
        itsIntFlowInterface.removeAll();
    }
}

DriverTapis::cmdC_SP_C::cmdC_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::cmdC_SP_C::~cmdC_SP_C() {
    cleanUpRelations();
}

void DriverTapis::cmdC_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void DriverTapis::cmdC_SP_C::connectDriverTapis(DriverTapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* DriverTapis::cmdC_SP_C::getItsIntFlowInterface() {
    return this;
}

void DriverTapis::cmdC_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::cmdC_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::debc_SP_C::debc_SP_C() : _p_(0) {
}

DriverTapis::debc_SP_C::~debc_SP_C() {
    cleanUpRelations();
}

void DriverTapis::debc_SP_C::SetValue(int data, void * pCaller) {
    
    for(int i = 0 ; i < itsIntFlowInterface.getCount() ; i++)
    {
        itsIntFlowInterface[i]->SetValue(data,pCaller);
        if(i < itsIntFlowInterface.getCount() - 1)
        {
            FLOW_DATA_POP
        }
    }
    
}

intFlowInterface* DriverTapis::debc_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::debc_SP_C::getOutBound() {
    return this;
}

intFlowInterface* DriverTapis::debc_SP_C::getItsIntFlowInterfaceAt(int i) const {
    return itsIntFlowInterface.getAt(i);
}

void DriverTapis::debc_SP_C::addItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.add(p_intFlowInterface);
}

void DriverTapis::debc_SP_C::removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface.remove(p_intFlowInterface);
}

void DriverTapis::debc_SP_C::clearItsIntFlowInterface() {
    itsIntFlowInterface.removeAll();
}

int DriverTapis::debc_SP_C::findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const {
    return itsIntFlowInterface.find(p_intFlowInterface);
}

void DriverTapis::debc_SP_C::cleanUpRelations() {
    {
        itsIntFlowInterface.removeAll();
    }
}

DriverTapis::finc_SP_C::finc_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::finc_SP_C::~finc_SP_C() {
    cleanUpRelations();
}

void DriverTapis::finc_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::finc_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::finc_SP_C::getOutBound() {
    return this;
}

void DriverTapis::finc_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::finc_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::cmdVerrin_SP_C::cmdVerrin_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::cmdVerrin_SP_C::~cmdVerrin_SP_C() {
    cleanUpRelations();
}

void DriverTapis::cmdVerrin_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void DriverTapis::cmdVerrin_SP_C::connectDriverTapis(DriverTapis* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* DriverTapis::cmdVerrin_SP_C::getItsIntFlowInterface() {
    return this;
}

void DriverTapis::cmdVerrin_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::cmdVerrin_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::mia_SP_C::mia_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::mia_SP_C::~mia_SP_C() {
    cleanUpRelations();
}

void DriverTapis::mia_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::mia_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::mia_SP_C::getOutBound() {
    return this;
}

void DriverTapis::mia_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::mia_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::mib_SP_C::mib_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::mib_SP_C::~mib_SP_C() {
    cleanUpRelations();
}

void DriverTapis::mib_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::mib_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::mib_SP_C::getOutBound() {
    return this;
}

void DriverTapis::mib_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::mib_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::dca_SP_C::dca_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::dca_SP_C::~dca_SP_C() {
    cleanUpRelations();
}

void DriverTapis::dca_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::dca_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::dca_SP_C::getOutBound() {
    return this;
}

void DriverTapis::dca_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::dca_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

DriverTapis::dcb_SP_C::dcb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

DriverTapis::dcb_SP_C::~dcb_SP_C() {
    cleanUpRelations();
}

void DriverTapis::dcb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* DriverTapis::dcb_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* DriverTapis::dcb_SP_C::getOutBound() {
    return this;
}

void DriverTapis::dcb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void DriverTapis::dcb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}
//#]

DriverTapis::DriverTapis(IOxfActive* theActiveContext) : bit(new char[8]), cmdA(0), cmdB(0), cmdC(0), cmdVerrin(0), connected(false), dca(-1), dcb(-1), deba(-1), debb(-1), debc(-1), fina(-1), finb(-1), finc(-1), flag(0), handle(new long[2]), id_maq_pc(31), mia(-1), mib(-1), okToSend(false), trame_entree(new char[3]), versa(-1), versb(-1) {
    NOTIFY_ACTIVE_CONSTRUCTOR(DriverTapis, DriverTapis(), 0, DriverTapisPkg_DriverTapis_DriverTapis_SERIALIZE);
    setActiveContext(this, true);
    initRelations();
    initStatechart();
    //#[ operation DriverTapis()
    // connectToMaquette(3,1); // numPC, numMaquette
    //#]
}

bool DriverTapis::connectToMaquette(int numPC, int numMaq) {
    NOTIFY_OPERATION(connectToMaquette, connectToMaquette(int,int), 2, DriverTapisPkg_DriverTapis_connectToMaquette_SERIALIZE);
    //#[ operation connectToMaquette(int,int)
    
    //initialisation driver CAN
        if ((handle[0] = CanOpenDriver(0, 0)) == -1)
        {
            printf("\nOpen Port 0 Failed!!");
            return false;
    	}
    num_pc=numPC;
    num_tapis = numMaq;
    id_maq_pc = (num_tapis*16)+num_pc ;
    printf ("PC %d -> choix Tapis %d \n", num_pc, num_tapis);
     
    
    printf ("Initialisation CAN.....");
    init_can(id_maq_pc);
    
    _7841_Write(handle[0],1,0x04);
    _7841_Write(handle[0],1,0x04);
    
    printf ("SUCCESS\n");
    
    printf ("Reinitialisation du tapis...\n");
    	bit[0]=0;
    	bit[1]=0;
    	bit[2]=0;
    	bit[3]=0;
    	bit[4]=0;
    	bit[5]=0;
    	bit[6]=0;
    	
    	trame_sortie=0;
    	      
    	sorties.Valeurs.mava = 0; 
    	sorties.Valeurs.mara = 0; 
    
    	sorties.Valeurs.mavb = 0; 
    	sorties.Valeurs.marb = 0; 
    	
    	sorties.Valeurs.mavc = 0; 
    	sorties.Valeurs.marc = 0; 
    
        sorties.Valeurs.ev = 0; 
            
        send_mess(sorties);
              
     //connected = true;
     
     printf ("connexion ok \n");
     return true;
    //#]
}

void DriverTapis::init_can(int id) {
    NOTIFY_OPERATION(init_can, init_can(int), 1, DriverTapisPkg_DriverTapis_init_can_SERIALIZE);
    //#[ operation init_can(int)
         //reset
    	_7841_Write(handle[0],0,0x01); 
    	
    	//CONFIGURATION
    	//CAN A
    	_7841_Write(handle[0],30,0x00);
    	
    	_7841_Write(handle[0],31,0x00);
    
    	_7841_Write(handle[0],8,0xFA);
    	//config BTR  50 kbis/s
    	_7841_Write(handle[0],6,0x07); //modif
    	
    	_7841_Write(handle[0],7,0x5c); // modif
    
    	//Config du mask
    	_7841_Write(handle[0],5,0x00);
    	_7841_Write(handle[0],4,id); // modif
    
    	//CAN A
    	_7841_Write(handle[0],30,0x00);
    	
    	_7841_Write(handle[0],31,0x00);
    	//relancer la carte
    	_7841_Write(handle[0],0,0x00);   
    	                                 
    	_7841_Write(handle[0],1,0x04);
    	_7841_Write(handle[0],1,0x04);      
    	
            
            
            
    //#]
}

int DriverTapis::recv_mess(Entrees * entrees) {
    NOTIFY_OPERATION(recv_mess, recv_mess(Entrees *), 1, DriverTapisPkg_DriverTapis_recv_mess_SERIALIZE);
    //#[ operation recv_mess(Entrees *)
    if(((_7841_Read(handle[0],2))&0x01)==1){
    		//printf("Dans le if \n");
    		trame_entree[0]=_7841_Read(handle[0],22);
    		trame_entree[1]=_7841_Read(handle[0],23);
    		trame_entree[2]=_7841_Read(handle[0],24);
    		
    		_7841_Write(handle[0],1,0x04);
    		
    		
    		//printf("Etat entrees\n\n");		
    		//printf("Debut cycle A :  %d\n",trame_entree[0]&0x01);		
    		(*entrees).Valeurs.dca = trame_entree[0]&0x01;
    		
    		//printf("Debut cycle B :  %d\n",(trame_entree[0]&0x02)/2);
    		(*entrees).Valeurs.dcb = (trame_entree[0]&0x02)/2;
    				
    		//printf("Debut tapis A :  %d\n",(trame_entree[0]&0x04)/4);
    		(*entrees).Valeurs.deba = (trame_entree[0]&0x04)/4;		
    				
    		//printf("Milieu tapis A :  %d\n",(trame_entree[0]&0x08)/8);
    		(*entrees).Valeurs.mia = (trame_entree[0]&0x08)/8;		
    		//if ((*entrees).Valeurs.mia==1) printf("#######      MIA        ###################### \n");
    				
    		//printf("Fin tapis A :  %d\n",trame_entree[1]&0x01);
    		(*entrees).Valeurs.fina = trame_entree[1]&0x01;		
    		
    		//printf("Debut tapis B :  %d\n",(trame_entree[1]&0x02)/2);
    		(*entrees).Valeurs.debb = (trame_entree[1]&0x02)/2;		
    		
    		//printf("Milieu Tapis B :  %d\n",(trame_entree[1]&0x04)/4);
    		(*entrees).Valeurs.mib = (trame_entree[1]&0x04)/4;		
    		
    		//printf("Fin tapis B :  %d\n",(trame_entree[1]&0x08)/8);
    		(*entrees).Valeurs.finb = (trame_entree[1]&0x08)/8;		
    		
    		//printf("Debut tapis C :  %d\n",trame_entree[2]&0x01);
    		(*entrees).Valeurs.debc = trame_entree[2]&0x01;		
    		
    		//printf("Fin tapis C :  %d\n",(trame_entree[2]&0x02)/2);
    		(*entrees).Valeurs.finc = (trame_entree[2]&0x02)/2;		
    		
    		//printf("Verin vers A :  %d\n",(trame_entree[2]&0x04)/4);
    		(*entrees).Valeurs.versa = (trame_entree[2]&0x04)/4;		
    		
    		//printf("Verin vers B :  %d\n",(trame_entree[2]&0x08)/8);
    	    (*entrees).Valeurs.versb = (trame_entree[2]&0x08)/8;		
    		
    				return(0);
    	}
    		else 
    		    
    		return(-1);  
    		
    		
    		
    //#]
}

void DriverTapis::send_mess(Sorties sorties) {
    NOTIFY_OPERATION(send_mess, send_mess(Sorties), 1, DriverTapisPkg_DriverTapis_send_mess_SERIALIZE);
    //#[ operation send_mess(Sorties)
    
       		bit[0]=sorties.Valeurs.mava;
    		bit[1]=sorties.Valeurs.mara;
    		bit[2]=sorties.Valeurs.mavb;		
    		bit[3]=sorties.Valeurs.marb;
    		bit[4]=sorties.Valeurs.mavc;
    		bit[5]=sorties.Valeurs.marc;
    		bit[6]=sorties.Valeurs.ev;
    //printf("sending (mava,mara,mavb,marb,mavc,marb,ev)=(%d,%d,%d,%d,%d,%d,%d)...", bit[0],bit[1],bit[2],bit[3],bit[4],bit[5],bit[6]);
            trame_sortie=bit[0]+bit[1]*2+bit[2]*4+bit[3]*8+bit[4]*16+bit[5]*32+bit[6]*64;
    
            while(((_7841_Read(handle[0],0x02))&0x04)==0);
    //printf("OK\n");
    		_7841_Write(handle[0],10,id_maq_pc);
    		_7841_Write(handle[0],11,0x01);
    		_7841_Write(handle[0],12,trame_sortie);
    		_7841_Write(handle[0],1,0x01);
                 
    //#]
}

DriverTapis::~DriverTapis() {
    NOTIFY_DESTRUCTOR(~DriverTapis, false);
    cancelTimeouts();
}

//#[ ignore
void DriverTapis::SetValue(int data, void * pCaller) {
    if (pCaller == (void *)get_cmdA_SP()) {
        setCmdA(data);
    }
    
    if (pCaller == (void *)get_cmdB_SP()) {
        setCmdB(data);
    }
    
    if (pCaller == (void *)get_cmdC_SP()) {
        setCmdC(data);
    }
    
    if (pCaller == (void *)get_cmdVerrin_SP()) {
        setCmdVerrin(data);
    }
}
//#]

int DriverTapis::readCapteurs() {
    NOTIFY_OPERATION(readCapteurs, readCapteurs(), 0, DriverTapisPkg_DriverTapis_readCapteurs_SERIALIZE);
    //#[ operation readCapteurs()
    int flag = recv_mess(&entrees);
    
    if (flag!=-1)
    {
    	// tapis A
    	setDca(entrees.Valeurs.dca); 
    	setDeba(entrees.Valeurs.deba);  	
    	setMia(entrees.Valeurs.mia); 
    	setFina(entrees.Valeurs.fina);  
    	
    	// tapis B         
    	setDcb(entrees.Valeurs.dcb); 
    	setDebb(entrees.Valeurs.debb); 
    	setMib(entrees.Valeurs.mib); 
    	setFinb(entrees.Valeurs.finb);  
    
    	//tapis C
    	setDebc(entrees.Valeurs.debc); 
    	setFinc(entrees.Valeurs.finc);   
    	
    	// verrin
    	setVersa(entrees.Valeurs.versa); 
    	setVersb(entrees.Valeurs.versb); 
    	
    }
    
    return flag;
    //#]
}

void DriverTapis::sendCmd() {
    NOTIFY_OPERATION(sendCmd, sendCmd(), 0, DriverTapisPkg_DriverTapis_sendCmd_SERIALIZE);
    //#[ operation sendCmd()
    Sorties s = sorties;
    
    if (cmdA==AVANCER){
    		s.Valeurs.mava = 1;
    		s.Valeurs.mara = 0;
    	 }                 
    else if (cmdA==RECULER){
    		s.Valeurs.mava = 0;
    		s.Valeurs.mara = 1;
    	 } else	if (cmdA==ARRETER)
    	 		 {
    				s.Valeurs.mava = 0;
    				s.Valeurs.mara = 0;	 
    	   	   }
    	 
    if (cmdB==AVANCER){
    		s.Valeurs.mavb = 1;
    		s.Valeurs.marb = 0;
    	 }                 
    else if (cmdB==RECULER){
    		s.Valeurs.mavb = 0;
    		s.Valeurs.marb = 1;
    	 } else	if (cmdB==ARRETER)
    	 		 {
    				s.Valeurs.mavb = 0;
    				s.Valeurs.marb = 0;	 
    	   	   }
    
    if (cmdC==AVANCER){
    		s.Valeurs.mavc = 1;
    		s.Valeurs.marc = 0;
    	 }                 
    else if (cmdC==RECULER){
    		s.Valeurs.mavc = 0;
    		s.Valeurs.marc = 1;
    	 } else	if (cmdC==ARRETER)
    	 		 {
    				s.Valeurs.mavc = 0;
    				s.Valeurs.marc = 0;	 
    	   	   }
    
    if (cmdVerrin==COTE_A)
    	s.Valeurs.ev = 1;  
    else if (cmdVerrin==COTE_B)
    	s.Valeurs.ev = 0;  
    
    sorties = s;
    send_mess(sorties);
    //#]
}

//#[ ignore
void DriverTapis::setCmdA(int p_cmdA) {
    if (cmdA != p_cmdA) {
        cmdA = p_cmdA;
        FLOW_DATA_RECEIVE("cmdA", cmdA, x2String);
    }
    
}

void DriverTapis::setCmdB(int p_cmdB) {
    if (cmdB != p_cmdB) {
        cmdB = p_cmdB;
        FLOW_DATA_RECEIVE("cmdB", cmdB, x2String);
    }
    
}

void DriverTapis::setCmdC(int p_cmdC) {
    if (cmdC != p_cmdC) {
        cmdC = p_cmdC;
        FLOW_DATA_RECEIVE("cmdC", cmdC, x2String);
    }
    
}

void DriverTapis::setCmdVerrin(int p_cmdVerrin) {
    if (cmdVerrin != p_cmdVerrin) {
        cmdVerrin = p_cmdVerrin;
        FLOW_DATA_RECEIVE("cmdVerrin", cmdVerrin, x2String);
    }
    
}

void DriverTapis::setDca(int p_dca) {
    if (dca != p_dca)  {
        dca = p_dca;
        FLOW_DATA_SEND(dca, dca_SP, SetValue, x2String);
    }
}

void DriverTapis::setDcb(int p_dcb) {
    if (dcb != p_dcb)  {
        dcb = p_dcb;
        FLOW_DATA_SEND(dcb, dcb_SP, SetValue, x2String);
    }
}

void DriverTapis::setDeba(int p_deba) {
    if (deba != p_deba)  {
        deba = p_deba;
        FLOW_DATA_SEND(deba, deba_SP, SetValue, x2String);
    }
}

void DriverTapis::setDebb(int p_debb) {
    if (debb != p_debb)  {
        debb = p_debb;
        FLOW_DATA_SEND(debb, debb_SP, SetValue, x2String);
    }
}

void DriverTapis::setDebc(int p_debc) {
    if (debc != p_debc)  {
        debc = p_debc;
        FLOW_DATA_SEND(debc, debc_SP, SetValue, x2String);
    }
}

void DriverTapis::setFina(int p_fina) {
    if (fina != p_fina)  {
        fina = p_fina;
        FLOW_DATA_SEND(fina, fina_SP, SetValue, x2String);
    }
}

void DriverTapis::setFinb(int p_finb) {
    if (finb != p_finb)  {
        finb = p_finb;
        FLOW_DATA_SEND(finb, finb_SP, SetValue, x2String);
    }
}

void DriverTapis::setFinc(int p_finc) {
    if (finc != p_finc)  {
        finc = p_finc;
        FLOW_DATA_SEND(finc, finc_SP, SetValue, x2String);
    }
}

void DriverTapis::setMia(int p_mia) {
    if (mia != p_mia)  {
        mia = p_mia;
        FLOW_DATA_SEND(mia, mia_SP, SetValue, x2String);
    }
}

void DriverTapis::setMib(int p_mib) {
    if (mib != p_mib)  {
        mib = p_mib;
        FLOW_DATA_SEND(mib, mib_SP, SetValue, x2String);
    }
}

void DriverTapis::setVersa(int p_versa) {
    if (versa != p_versa)  {
        versa = p_versa;
        FLOW_DATA_SEND(versa, versa_SP, SetValue, x2String);
    }
}

void DriverTapis::setVersb(int p_versb) {
    if (versb != p_versb)  {
        versb = p_versb;
        FLOW_DATA_SEND(versb, versb_SP, SetValue, x2String);
    }
}
//#]

DriverTapis::connect_C* DriverTapis::getConnect() const {
    return (DriverTapis::connect_C*) &connect;
}

DriverTapis::connect_C* DriverTapis::get_connect() const {
    return (DriverTapis::connect_C*) &connect;
}

DriverTapis::cmdA_SP_C* DriverTapis::getCmdA_SP() const {
    return (DriverTapis::cmdA_SP_C*) &cmdA_SP;
}

DriverTapis::cmdA_SP_C* DriverTapis::get_cmdA_SP() const {
    return (DriverTapis::cmdA_SP_C*) &cmdA_SP;
}

DriverTapis::deba_SP_C* DriverTapis::getDeba_SP() const {
    return (DriverTapis::deba_SP_C*) &deba_SP;
}

DriverTapis::deba_SP_C* DriverTapis::get_deba_SP() const {
    return (DriverTapis::deba_SP_C*) &deba_SP;
}

DriverTapis::versa_SP_C* DriverTapis::getVersa_SP() const {
    return (DriverTapis::versa_SP_C*) &versa_SP;
}

DriverTapis::versa_SP_C* DriverTapis::get_versa_SP() const {
    return (DriverTapis::versa_SP_C*) &versa_SP;
}

DriverTapis::fina_SP_C* DriverTapis::getFina_SP() const {
    return (DriverTapis::fina_SP_C*) &fina_SP;
}

DriverTapis::fina_SP_C* DriverTapis::get_fina_SP() const {
    return (DriverTapis::fina_SP_C*) &fina_SP;
}

DriverTapis::cmdB_SP_C* DriverTapis::getCmdB_SP() const {
    return (DriverTapis::cmdB_SP_C*) &cmdB_SP;
}

DriverTapis::cmdB_SP_C* DriverTapis::get_cmdB_SP() const {
    return (DriverTapis::cmdB_SP_C*) &cmdB_SP;
}

DriverTapis::debb_SP_C* DriverTapis::getDebb_SP() const {
    return (DriverTapis::debb_SP_C*) &debb_SP;
}

DriverTapis::debb_SP_C* DriverTapis::get_debb_SP() const {
    return (DriverTapis::debb_SP_C*) &debb_SP;
}

DriverTapis::versb_SP_C* DriverTapis::getVersb_SP() const {
    return (DriverTapis::versb_SP_C*) &versb_SP;
}

DriverTapis::versb_SP_C* DriverTapis::get_versb_SP() const {
    return (DriverTapis::versb_SP_C*) &versb_SP;
}

DriverTapis::finb_SP_C* DriverTapis::getFinb_SP() const {
    return (DriverTapis::finb_SP_C*) &finb_SP;
}

DriverTapis::finb_SP_C* DriverTapis::get_finb_SP() const {
    return (DriverTapis::finb_SP_C*) &finb_SP;
}

DriverTapis::cmdC_SP_C* DriverTapis::getCmdC_SP() const {
    return (DriverTapis::cmdC_SP_C*) &cmdC_SP;
}

DriverTapis::cmdC_SP_C* DriverTapis::get_cmdC_SP() const {
    return (DriverTapis::cmdC_SP_C*) &cmdC_SP;
}

DriverTapis::debc_SP_C* DriverTapis::getDebc_SP() const {
    return (DriverTapis::debc_SP_C*) &debc_SP;
}

DriverTapis::debc_SP_C* DriverTapis::get_debc_SP() const {
    return (DriverTapis::debc_SP_C*) &debc_SP;
}

DriverTapis::finc_SP_C* DriverTapis::getFinc_SP() const {
    return (DriverTapis::finc_SP_C*) &finc_SP;
}

DriverTapis::finc_SP_C* DriverTapis::get_finc_SP() const {
    return (DriverTapis::finc_SP_C*) &finc_SP;
}

DriverTapis::cmdVerrin_SP_C* DriverTapis::getCmdVerrin_SP() const {
    return (DriverTapis::cmdVerrin_SP_C*) &cmdVerrin_SP;
}

DriverTapis::cmdVerrin_SP_C* DriverTapis::get_cmdVerrin_SP() const {
    return (DriverTapis::cmdVerrin_SP_C*) &cmdVerrin_SP;
}

DriverTapis::mia_SP_C* DriverTapis::getMia_SP() const {
    return (DriverTapis::mia_SP_C*) &mia_SP;
}

DriverTapis::mia_SP_C* DriverTapis::get_mia_SP() const {
    return (DriverTapis::mia_SP_C*) &mia_SP;
}

DriverTapis::mib_SP_C* DriverTapis::getMib_SP() const {
    return (DriverTapis::mib_SP_C*) &mib_SP;
}

DriverTapis::mib_SP_C* DriverTapis::get_mib_SP() const {
    return (DriverTapis::mib_SP_C*) &mib_SP;
}

DriverTapis::dca_SP_C* DriverTapis::getDca_SP() const {
    return (DriverTapis::dca_SP_C*) &dca_SP;
}

DriverTapis::dca_SP_C* DriverTapis::get_dca_SP() const {
    return (DriverTapis::dca_SP_C*) &dca_SP;
}

DriverTapis::dcb_SP_C* DriverTapis::getDcb_SP() const {
    return (DriverTapis::dcb_SP_C*) &dcb_SP;
}

DriverTapis::dcb_SP_C* DriverTapis::get_dcb_SP() const {
    return (DriverTapis::dcb_SP_C*) &dcb_SP;
}

int DriverTapis::getCmdA() const {
    return cmdA;
}

int DriverTapis::getCmdB() const {
    return cmdB;
}

int DriverTapis::getCmdC() const {
    return cmdC;
}

int DriverTapis::getCmdVerrin() const {
    return cmdVerrin;
}

bool DriverTapis::getConnected() const {
    return connected;
}

void DriverTapis::setConnected(bool p_connected) {
    connected = p_connected;
}

int DriverTapis::getDca() const {
    return dca;
}

int DriverTapis::getDcb() const {
    return dcb;
}

int DriverTapis::getDeba() const {
    return deba;
}

int DriverTapis::getDebb() const {
    return debb;
}

int DriverTapis::getDebc() const {
    return debc;
}

int DriverTapis::getFina() const {
    return fina;
}

int DriverTapis::getFinb() const {
    return finb;
}

int DriverTapis::getFinc() const {
    return finc;
}

int DriverTapis::getFlag() const {
    return flag;
}

void DriverTapis::setFlag(int p_flag) {
    flag = p_flag;
}

int DriverTapis::getMia() const {
    return mia;
}

int DriverTapis::getMib() const {
    return mib;
}

bool DriverTapis::getOkToSend() const {
    return okToSend;
}

void DriverTapis::setOkToSend(bool p_okToSend) {
    okToSend = p_okToSend;
}

int DriverTapis::getVersa() const {
    return versa;
}

int DriverTapis::getVersb() const {
    return versb;
}

bool DriverTapis::startBehavior() {
    bool done = false;
    done = OMReactive::startBehavior();
    if(done)
        {
            startDispatching();
        }
    return done;
}

void DriverTapis::initRelations() {
    if (get_connect() != NULL) {
        get_connect()->connectDriverTapis(this);
    }
    if (get_cmdA_SP() != NULL) {
        get_cmdA_SP()->connectDriverTapis(this);
    }
    if (get_cmdB_SP() != NULL) {
        get_cmdB_SP()->connectDriverTapis(this);
    }
    if (get_cmdC_SP() != NULL) {
        get_cmdC_SP()->connectDriverTapis(this);
    }
    if (get_cmdVerrin_SP() != NULL) {
        get_cmdVerrin_SP()->connectDriverTapis(this);
    }
}

void DriverTapis::initStatechart() {
    rootState_subState = OMNonState;
    rootState_active = OMNonState;
    rootState_timeout = NULL;
    state_2_subState = OMNonState;
    state_2_timeout = NULL;
}

void DriverTapis::cancelTimeouts() {
    cancel(rootState_timeout);
    cancel(state_2_timeout);
}

bool DriverTapis::cancelTimeout(const IOxfTimeout* arg) {
    bool res = false;
    if(rootState_timeout == arg)
        {
            rootState_timeout = NULL;
            res = true;
        }
    if(state_2_timeout == arg)
        {
            state_2_timeout = NULL;
            res = true;
        }
    return res;
}

char* DriverTapis::getBit() const {
    return bit;
}

void DriverTapis::setBit(char* p_bit) {
    bit = p_bit;
}

Entrees DriverTapis::getEntrees() const {
    return entrees;
}

void DriverTapis::setEntrees(Entrees p_entrees) {
    entrees = p_entrees;
}

long* DriverTapis::getHandle() const {
    return handle;
}

void DriverTapis::setHandle(long* p_handle) {
    handle = p_handle;
}

int DriverTapis::getId_maq_pc() const {
    return id_maq_pc;
}

void DriverTapis::setId_maq_pc(int p_id_maq_pc) {
    id_maq_pc = p_id_maq_pc;
}

int DriverTapis::getNum_pc() const {
    return num_pc;
}

void DriverTapis::setNum_pc(int p_num_pc) {
    num_pc = p_num_pc;
}

int DriverTapis::getNum_tapis() const {
    return num_tapis;
}

void DriverTapis::setNum_tapis(int p_num_tapis) {
    num_tapis = p_num_tapis;
}

Sorties DriverTapis::getSorties() const {
    return sorties;
}

void DriverTapis::setSorties(Sorties p_sorties) {
    sorties = p_sorties;
}

char* DriverTapis::getTrame_entree() const {
    return trame_entree;
}

void DriverTapis::setTrame_entree(char* p_trame_entree) {
    trame_entree = p_trame_entree;
}

char DriverTapis::getTrame_sortie() const {
    return trame_sortie;
}

void DriverTapis::setTrame_sortie(char p_trame_sortie) {
    trame_sortie = p_trame_sortie;
}

int DriverTapis::getVal() const {
    return val;
}

void DriverTapis::setVal(int p_val) {
    val = p_val;
}

void DriverTapis::rootState_entDef() {
    {
        NOTIFY_STATE_ENTERED("ROOT");
        NOTIFY_TRANSITION_STARTED("0");
        //#[ transition 0 
        connected = connectToMaquette( 5,2);  // NUM PC, NUM Maquette
        //#]
        NOTIFY_STATE_ENTERED("ROOT.state_6");
        pushNullTransition();
        rootState_subState = state_6;
        rootState_active = state_6;
        rootState_timeout = scheduleTimeout(500, "ROOT.state_6");
        NOTIFY_TRANSITION_TERMINATED("0");
    }
}

IOxfReactive::TakeEventStatus DriverTapis::rootState_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (rootState_active) {
        // State state_0
        case state_0:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == state_2_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("2");
                            cancel(state_2_timeout);
                            NOTIFY_STATE_EXITED("ROOT.state_2.state_0");
                            //#[ transition 2 
                            
                            
                            
                            sendCmd();
                            flag = readCapteurs(); // flag !=-1 SI au moins un capteur a chang� d'�tat.
                            
                            if (flag!=-1)
                            {
                            	// dans le IF si changement de la valeur d'un des capteurs. 
                            	printf("dca =%d  dcb=%d deba=%d debb=%d mia=%d mib=%d fina=%d finb=%d versa=%d versb=%d debc=%d finc=%d \n", dca, dcb, deba, debb, mia, mib, fina, finb, versa, versb, debc, finc);
                            
                                // A COMPLETER...
                            
                              
                            }
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_2.state_0");
                            state_2_subState = state_0;
                            rootState_active = state_0;
                            state_2_timeout = scheduleTimeout(100, "ROOT.state_2.state_0");
                            NOTIFY_TRANSITION_TERMINATED("2");
                            res = eventConsumed;
                        }
                }
            
            
        }
        break;
        // State state_6
        case state_6:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == rootState_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("4");
                            popNullTransition();
                            cancel(rootState_timeout);
                            NOTIFY_STATE_EXITED("ROOT.state_6");
                            NOTIFY_STATE_ENTERED("ROOT.state_6");
                            pushNullTransition();
                            rootState_subState = state_6;
                            rootState_active = state_6;
                            rootState_timeout = scheduleTimeout(500, "ROOT.state_6");
                            NOTIFY_TRANSITION_TERMINATED("4");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(OMNullEventId))
                {
                    //## transition 3 
                    if(connected == true)
                        {
                            NOTIFY_TRANSITION_STARTED("3");
                            popNullTransition();
                            cancel(rootState_timeout);
                            NOTIFY_STATE_EXITED("ROOT.state_6");
                            state_2_entDef();
                            NOTIFY_TRANSITION_TERMINATED("3");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        default:
            break;
    }
    return res;
}

void DriverTapis::state_2_entDef() {
    NOTIFY_STATE_ENTERED("ROOT.state_2");
    rootState_subState = state_2;
    NOTIFY_TRANSITION_STARTED("1");
    NOTIFY_STATE_ENTERED("ROOT.state_2.state_0");
    state_2_subState = state_0;
    rootState_active = state_0;
    state_2_timeout = scheduleTimeout(100, "ROOT.state_2.state_0");
    NOTIFY_TRANSITION_TERMINATED("1");
}

void DriverTapis::state_2_exit() {
    // State state_0
    if(state_2_subState == state_0)
        {
            cancel(state_2_timeout);
            NOTIFY_STATE_EXITED("ROOT.state_2.state_0");
        }
    state_2_subState = OMNonState;
    
    NOTIFY_STATE_EXITED("ROOT.state_2");
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimatedDriverTapis::serializeAttributes(AOMSAttributes* aomsAttributes) const {
    aomsAttributes->addAttribute("handle", x2String(myReal->handle));
    aomsAttributes->addAttribute("num_tapis", x2String(myReal->num_tapis));
    aomsAttributes->addAttribute("trame_sortie", x2String(myReal->trame_sortie));
    aomsAttributes->addAttribute("trame_entree", x2String(myReal->trame_entree));
    aomsAttributes->addAttribute("val", x2String(myReal->val));
    aomsAttributes->addAttribute("bit", x2String(myReal->bit));
    aomsAttributes->addAttribute("sorties", UNKNOWN2STRING(myReal->sorties));
    aomsAttributes->addAttribute("num_pc", x2String(myReal->num_pc));
    aomsAttributes->addAttribute("id_maq_pc", x2String(myReal->id_maq_pc));
    aomsAttributes->addAttribute("dca", x2String(myReal->dca));
    aomsAttributes->addAttribute("deba", x2String(myReal->deba));
    aomsAttributes->addAttribute("mia", x2String(myReal->mia));
    aomsAttributes->addAttribute("fina", x2String(myReal->fina));
    aomsAttributes->addAttribute("dcb", x2String(myReal->dcb));
    aomsAttributes->addAttribute("debb", x2String(myReal->debb));
    aomsAttributes->addAttribute("mib", x2String(myReal->mib));
    aomsAttributes->addAttribute("finb", x2String(myReal->finb));
    aomsAttributes->addAttribute("versa", x2String(myReal->versa));
    aomsAttributes->addAttribute("versb", x2String(myReal->versb));
    aomsAttributes->addAttribute("debc", x2String(myReal->debc));
    aomsAttributes->addAttribute("finc", x2String(myReal->finc));
    aomsAttributes->addAttribute("flag", x2String(myReal->flag));
    aomsAttributes->addAttribute("entrees", UNKNOWN2STRING(myReal->entrees));
    aomsAttributes->addAttribute("okToSend", x2String(myReal->okToSend));
    aomsAttributes->addAttribute("cmdA", x2String(myReal->cmdA));
    aomsAttributes->addAttribute("connected", x2String(myReal->connected));
    aomsAttributes->addAttribute("cmdB", x2String(myReal->cmdB));
    aomsAttributes->addAttribute("cmdC", x2String(myReal->cmdC));
    aomsAttributes->addAttribute("cmdVerrin", x2String(myReal->cmdVerrin));
    OMAnimatedIConnect::serializeAttributes(aomsAttributes);
}

void OMAnimatedDriverTapis::serializeRelations(AOMSRelations* aomsRelations) const {
    OMAnimatedIConnect::serializeRelations(aomsRelations);
}

void OMAnimatedDriverTapis::rootState_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT");
    switch (myReal->rootState_subState) {
        case DriverTapis::state_2:
        {
            state_2_serializeStates(aomsState);
        }
        break;
        case DriverTapis::state_6:
        {
            state_6_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimatedDriverTapis::state_6_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_6");
}

void OMAnimatedDriverTapis::state_2_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_2");
    if(myReal->state_2_subState == DriverTapis::state_0)
        {
            state_0_serializeStates(aomsState);
        }
}

void OMAnimatedDriverTapis::state_0_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_2.state_0");
}
//#]

IMPLEMENT_REACTIVE_META_S_P(DriverTapis, DriverTapisPkg, false, IConnect, OMAnimatedIConnect, OMAnimatedDriverTapis)

OMINIT_SUPERCLASS(IConnect, OMAnimatedIConnect)

OMREGISTER_REACTIVE_CLASS
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\DriverTapis.cpp
*********************************************************************/
