/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: _DESIGN
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\_DESIGN.h
*********************************************************************/

#ifndef _DESIGN_H
#define _DESIGN_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include <oxf\event.h>
//## dependency DriverTapisPkg
#include "DriverTapisPkg.h"
//## auto_generated
class SysConvoyage;

//## auto_generated
class Verrin;

//## auto_generated
class tapis;

//## auto_generated
class tapisC;

//#[ ignore
#define chDeb__DESIGN_id 15001

#define chVers__DESIGN_id 15002

#define chFin__DESIGN_id 15003

#define chMia__DESIGN_id 15004

#define chVersa__DESIGN_id 15005

#define chDebc__DESIGN_id 15006

#define chMib__DESIGN_id 15007

#define chVersb__DESIGN_id 15008

#define chFinb__DESIGN_id 15009

#define chFina__DESIGN_id 15010

#define chDc__DESIGN_id 15011
//#]

//## package _DESIGN



//## event chDeb()
class chDeb : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchDeb;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chDeb();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchDeb : virtual public AOMEvent {
    DECLARE_META_EVENT(chDeb)
};
//#]
#endif // _OMINSTRUMENT

//## event chVers()
class chVers : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchVers;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chVers();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchVers : virtual public AOMEvent {
    DECLARE_META_EVENT(chVers)
};
//#]
#endif // _OMINSTRUMENT

//## event chFin()
class chFin : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchFin;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chFin();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchFin : virtual public AOMEvent {
    DECLARE_META_EVENT(chFin)
};
//#]
#endif // _OMINSTRUMENT

//## event chMia()
class chMia : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchMia;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chMia();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchMia : virtual public AOMEvent {
    DECLARE_META_EVENT(chMia)
};
//#]
#endif // _OMINSTRUMENT

//## event chVersa()
class chVersa : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchVersa;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chVersa();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchVersa : virtual public AOMEvent {
    DECLARE_META_EVENT(chVersa)
};
//#]
#endif // _OMINSTRUMENT

//## event chDebc()
class chDebc : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchDebc;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chDebc();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchDebc : virtual public AOMEvent {
    DECLARE_META_EVENT(chDebc)
};
//#]
#endif // _OMINSTRUMENT

//## event chMib()
class chMib : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchMib;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chMib();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchMib : virtual public AOMEvent {
    DECLARE_META_EVENT(chMib)
};
//#]
#endif // _OMINSTRUMENT

//## event chVersb()
class chVersb : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchVersb;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chVersb();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchVersb : virtual public AOMEvent {
    DECLARE_META_EVENT(chVersb)
};
//#]
#endif // _OMINSTRUMENT

//## event chFinb()
class chFinb : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchFinb;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chFinb();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchFinb : virtual public AOMEvent {
    DECLARE_META_EVENT(chFinb)
};
//#]
#endif // _OMINSTRUMENT

//## event chFina()
class chFina : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchFina;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chFina();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchFina : virtual public AOMEvent {
    DECLARE_META_EVENT(chFina)
};
//#]
#endif // _OMINSTRUMENT

//## event chDc()
class chDc : public OMEvent {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedchDc;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    chDc();
    
    ////    Framework operations    ////
    
    //## statechart_method
    virtual bool isTypeOf(const short id) const;
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedchDc : virtual public AOMEvent {
    DECLARE_META_EVENT(chDc)
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\_DESIGN.h
*********************************************************************/
