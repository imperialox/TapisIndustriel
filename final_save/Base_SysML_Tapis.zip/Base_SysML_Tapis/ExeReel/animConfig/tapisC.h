/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: tapisC
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\tapisC.h
*********************************************************************/

#ifndef tapisC_H
#define tapisC_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include "_DESIGN.h"
//## auto_generated
#include <oxf\omthread.h>
//## auto_generated
#include <oxf\omreactive.h>
//## auto_generated
#include <oxf\state.h>
//## auto_generated
#include <oxf\event.h>
//## class tapisC
#include "intFlowInterface.h"
//## package _DESIGN

//## class tapisC
class tapisC : public OMReactive, public intFlowInterface {
public :

//#[ ignore
    //## package _DESIGN
    class cmd_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        cmd_SP_C();
        
        //## auto_generated
        virtual ~cmd_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class deb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        deb_SP_C();
        
        //## auto_generated
        virtual ~deb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapisC(tapisC* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class versa_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        versa_SP_C();
        
        //## auto_generated
        virtual ~versa_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapisC(tapisC* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class fin_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        fin_SP_C();
        
        //## auto_generated
        virtual ~fin_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapisC(tapisC* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class versb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        versb_SP_C();
        
        //## auto_generated
        virtual ~versb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapisC(tapisC* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class finb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        finb_SP_C();
        
        //## auto_generated
        virtual ~finb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapisC(tapisC* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class fina_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        fina_SP_C();
        
        //## auto_generated
        virtual ~fina_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapisC(tapisC* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
//#]

    ////    Friends    ////
    
#ifdef _OMINSTRUMENT
    friend class OMAnimatedtapisC;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    tapisC(IOxfActive* theActiveContext = 0);
    
    //## auto_generated
    ~tapisC();
    
    ////    Operations    ////
    
//#[ ignore
    void SetValue(int data, void * pCaller = NULL);
    
    void setCmd(int p_cmd);
    
    void setDeb(int p_deb);
    
    void setFin(int p_fin);
    
    void setFina(int p_fina);
    
    void setFinb(int p_finb);
    
    void setVersa(int p_versa);
    
    void setVersb(int p_versb);
//#]

    ////    Additional operations    ////
    
    //## auto_generated
    cmd_SP_C* getCmd_SP() const;
    
    //## auto_generated
    cmd_SP_C* get_cmd_SP() const;
    
    //## auto_generated
    deb_SP_C* getDeb_SP() const;
    
    //## auto_generated
    deb_SP_C* get_deb_SP() const;
    
    //## auto_generated
    versa_SP_C* getVersa_SP() const;
    
    //## auto_generated
    versa_SP_C* get_versa_SP() const;
    
    //## auto_generated
    fin_SP_C* getFin_SP() const;
    
    //## auto_generated
    fin_SP_C* get_fin_SP() const;
    
    //## auto_generated
    versb_SP_C* getVersb_SP() const;
    
    //## auto_generated
    versb_SP_C* get_versb_SP() const;
    
    //## auto_generated
    finb_SP_C* getFinb_SP() const;
    
    //## auto_generated
    finb_SP_C* get_finb_SP() const;
    
    //## auto_generated
    fina_SP_C* getFina_SP() const;
    
    //## auto_generated
    fina_SP_C* get_fina_SP() const;
    
    //## auto_generated
    int getCmd() const;
    
    //## auto_generated
    int getDeb() const;
    
    //## auto_generated
    int getFin() const;
    
    //## auto_generated
    int getFina() const;
    
    //## auto_generated
    int getFinb() const;
    
    //## auto_generated
    int getVersa() const;
    
    //## auto_generated
    int getVersb() const;
    
    //## auto_generated
    virtual bool startBehavior();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void initStatechart();
    
    //## auto_generated
    void cancelTimeouts();
    
    //## auto_generated
    bool cancelTimeout(const IOxfTimeout* arg);
    
    ////    Attributes    ////
    
    int cmd;		//## attribute cmd
    
    int deb;		//## attribute deb
    
    int fin;		//## attribute fin
    
    int fina;		//## attribute fina
    
    int finb;		//## attribute finb
    
    int versa;		//## attribute versa
    
    int versb;		//## attribute versb
    
    ////    Relations and components    ////
    
//#[ ignore
    cmd_SP_C cmd_SP;
    
    deb_SP_C deb_SP;
    
    versa_SP_C versa_SP;
    
    fin_SP_C fin_SP;
    
    versb_SP_C versb_SP;
    
    finb_SP_C finb_SP;
    
    fina_SP_C fina_SP;
//#]

    ////    Framework operations    ////

public :

    // rootState:
    //## statechart_method
    inline bool rootState_IN() const;
    
    //## statechart_method
    virtual void rootState_entDef();
    
    //## statechart_method
    virtual IOxfReactive::TakeEventStatus rootState_processEvent();
    
    // state_4:
    //## statechart_method
    inline bool state_4_IN() const;
    
    // state_3:
    //## statechart_method
    inline bool state_3_IN() const;
    
    // state_1:
    //## statechart_method
    inline bool state_1_IN() const;
    
    // state_0:
    //## statechart_method
    inline bool state_0_IN() const;
    
    ////    Framework    ////

protected :

//#[ ignore
    enum tapisC_Enum {
        OMNonState = 0,
        state_4 = 1,
        state_3 = 2,
        state_1 = 3,
        state_0 = 4
    };
    
    int rootState_subState;
    
    int rootState_active;
    
    IOxfTimeout* rootState_timeout;
//#]
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedtapisC : virtual public AOMInstance {
    DECLARE_REACTIVE_META(tapisC, OMAnimatedtapisC)
    
    ////    Framework operations    ////
    
public :

    virtual void serializeAttributes(AOMSAttributes* aomsAttributes) const;
    
    virtual void serializeRelations(AOMSRelations* aomsRelations) const;
    
    //## statechart_method
    void rootState_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_4_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_3_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_1_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_0_serializeStates(AOMSState* aomsState) const;
};
//#]
#endif // _OMINSTRUMENT

inline bool tapisC::rootState_IN() const {
    return true;
}

inline bool tapisC::state_4_IN() const {
    return rootState_subState == state_4;
}

inline bool tapisC::state_3_IN() const {
    return rootState_subState == state_3;
}

inline bool tapisC::state_1_IN() const {
    return rootState_subState == state_1;
}

inline bool tapisC::state_0_IN() const {
    return rootState_subState == state_0;
}

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\tapisC.h
*********************************************************************/
