/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: DriverTapis
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\DriverTapis.h
*********************************************************************/

#ifndef DriverTapis_H
#define DriverTapis_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include "DriverTapisPkg.h"
//## auto_generated
#include <oxf\omthread.h>
//## auto_generated
#include <oxf\omreactive.h>
//## auto_generated
#include <oxf\state.h>
//## auto_generated
#include <oxf\event.h>
//## class DriverTapis
#include "IConnect.h"
//## class DriverTapis
#include "intFlowInterface.h"
//## auto_generated
#include <oxf\omcollec.h>
//## package DriverTapisPkg

//## class DriverTapis
class DriverTapis : public OMThread, public OMReactive, public IConnect, public intFlowInterface {
public :

//#[ ignore
    //## package DriverTapisPkg
    class connect_C : public IConnect {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        connect_C();
        
        //## auto_generated
        virtual ~connect_C();
        
        ////    Operations    ////
        
        //## auto_generated
        void connectDriverTapis(DriverTapis* part);
        
        //## auto_generated
        virtual bool connectToMaquette(int numPC, int numMaq);
        
        //## auto_generated
        IConnect* getItsIConnect();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIConnect(IConnect* p_IConnect);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        IConnect* itsIConnect;		//## link itsIConnect
    };
    
    //## package DriverTapisPkg
    class cmdA_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        cmdA_SP_C();
        
        //## auto_generated
        virtual ~cmdA_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectDriverTapis(DriverTapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class deba_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        deba_SP_C();
        
        //## auto_generated
        virtual ~deba_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class versa_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        versa_SP_C();
        
        //## auto_generated
        virtual ~versa_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterfaceAt(int i) const;
        
        //## auto_generated
        void addItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void clearItsIntFlowInterface();
        
        //## auto_generated
        int findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const;
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        OMCollection<intFlowInterface*> itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class fina_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        fina_SP_C();
        
        //## auto_generated
        virtual ~fina_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterfaceAt(int i) const;
        
        //## auto_generated
        void addItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void clearItsIntFlowInterface();
        
        //## auto_generated
        int findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const;
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        OMCollection<intFlowInterface*> itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class cmdB_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        cmdB_SP_C();
        
        //## auto_generated
        virtual ~cmdB_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectDriverTapis(DriverTapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class debb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        debb_SP_C();
        
        //## auto_generated
        virtual ~debb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class versb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        versb_SP_C();
        
        //## auto_generated
        virtual ~versb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterfaceAt(int i) const;
        
        //## auto_generated
        void addItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void clearItsIntFlowInterface();
        
        //## auto_generated
        int findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const;
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        OMCollection<intFlowInterface*> itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class finb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        finb_SP_C();
        
        //## auto_generated
        virtual ~finb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterfaceAt(int i) const;
        
        //## auto_generated
        void addItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void clearItsIntFlowInterface();
        
        //## auto_generated
        int findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const;
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        OMCollection<intFlowInterface*> itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class cmdC_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        cmdC_SP_C();
        
        //## auto_generated
        virtual ~cmdC_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectDriverTapis(DriverTapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class debc_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        debc_SP_C();
        
        //## auto_generated
        virtual ~debc_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterfaceAt(int i) const;
        
        //## auto_generated
        void addItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void clearItsIntFlowInterface();
        
        //## auto_generated
        int findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const;
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        OMCollection<intFlowInterface*> itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class finc_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        finc_SP_C();
        
        //## auto_generated
        virtual ~finc_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class cmdVerrin_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        cmdVerrin_SP_C();
        
        //## auto_generated
        virtual ~cmdVerrin_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectDriverTapis(DriverTapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class mia_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        mia_SP_C();
        
        //## auto_generated
        virtual ~mia_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class mib_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        mib_SP_C();
        
        //## auto_generated
        virtual ~mib_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class dca_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        dca_SP_C();
        
        //## auto_generated
        virtual ~dca_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package DriverTapisPkg
    class dcb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        dcb_SP_C();
        
        //## auto_generated
        virtual ~dcb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
//#]

    ////    Friends    ////
    
#ifdef _OMINSTRUMENT
    friend class OMAnimatedDriverTapis;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## operation DriverTapis()
    DriverTapis(IOxfActive* theActiveContext = 0);
    
    ////    Operations    ////
    
    //## operation connectToMaquette(int,int)
    bool connectToMaquette(int numPC, int numMaq);

private :

    //## operation init_can(int)
    virtual void init_can(int id);
    
    //## operation recv_mess(Entrees *)
    virtual int recv_mess(Entrees * entrees);
    
    //## operation send_mess(Sorties)
    virtual void send_mess(Sorties sorties);
    
    ////    Additional operations    ////
    
    ////    Attributes    ////

protected :

    char* bit;		//## attribute bit
    
    int dca;		//## attribute dca
    
    int dcb;		//## attribute dcb
    
    int deba;		//## attribute deba
    
    int debb;		//## attribute debb
    
    int debc;		//## attribute debc
    
    Entrees entrees;		//## attribute entrees
    
    int fina;		//## attribute fina
    
    int finb;		//## attribute finb
    
    int finc;		//## attribute finc
    
    int flag;		//## attribute flag
    
    long* handle;		//## attribute handle
    
    int id_maq_pc;		//## attribute id_maq_pc
    
    int mia;		//## attribute mia
    
    int mib;		//## attribute mib
    
    int num_pc;		//## attribute num_pc
    
    int num_tapis;		//## attribute num_tapis
    
    bool okToSend;		//## attribute okToSend
    
    Sorties sorties;		//## attribute sorties
    
    char* trame_entree;		//## attribute trame_entree
    
    char trame_sortie;		//## attribute trame_sortie
    
    int val;		//## attribute val
    
    int versa;		//## attribute versa
    
    int versb;		//## attribute versb
    
    ////    Relations and components    ////
    
    ////    Framework operations    ////
    
    ////    Framework    ////
    
    int cmdA;		//## attribute cmdA
    
    int cmdB;		//## attribute cmdB
    
    int cmdC;		//## attribute cmdC
    
    int cmdVerrin;		//## attribute cmdVerrin
    
    bool connected;		//## attribute connected

public :

    //## auto_generated
    virtual ~DriverTapis();
    
//#[ ignore
    void SetValue(int data, void * pCaller = NULL);
//#]

    //## operation readCapteurs()
    virtual int readCapteurs();
    
    //## operation sendCmd()
    virtual void sendCmd();
    
//#[ ignore
    void setCmdA(int p_cmdA);
    
    void setCmdB(int p_cmdB);
    
    void setCmdC(int p_cmdC);
    
    void setCmdVerrin(int p_cmdVerrin);
    
    void setDca(int p_dca);
    
    void setDcb(int p_dcb);
    
    void setDeba(int p_deba);
    
    void setDebb(int p_debb);
    
    void setDebc(int p_debc);
    
    void setFina(int p_fina);
    
    void setFinb(int p_finb);
    
    void setFinc(int p_finc);
    
    void setMia(int p_mia);
    
    void setMib(int p_mib);
    
    void setVersa(int p_versa);
    
    void setVersb(int p_versb);
//#]

    //## auto_generated
    connect_C* getConnect() const;
    
    //## auto_generated
    connect_C* get_connect() const;
    
    //## auto_generated
    cmdA_SP_C* getCmdA_SP() const;
    
    //## auto_generated
    cmdA_SP_C* get_cmdA_SP() const;
    
    //## auto_generated
    deba_SP_C* getDeba_SP() const;
    
    //## auto_generated
    deba_SP_C* get_deba_SP() const;
    
    //## auto_generated
    versa_SP_C* getVersa_SP() const;
    
    //## auto_generated
    versa_SP_C* get_versa_SP() const;
    
    //## auto_generated
    fina_SP_C* getFina_SP() const;
    
    //## auto_generated
    fina_SP_C* get_fina_SP() const;
    
    //## auto_generated
    cmdB_SP_C* getCmdB_SP() const;
    
    //## auto_generated
    cmdB_SP_C* get_cmdB_SP() const;
    
    //## auto_generated
    debb_SP_C* getDebb_SP() const;
    
    //## auto_generated
    debb_SP_C* get_debb_SP() const;
    
    //## auto_generated
    versb_SP_C* getVersb_SP() const;
    
    //## auto_generated
    versb_SP_C* get_versb_SP() const;
    
    //## auto_generated
    finb_SP_C* getFinb_SP() const;
    
    //## auto_generated
    finb_SP_C* get_finb_SP() const;
    
    //## auto_generated
    cmdC_SP_C* getCmdC_SP() const;
    
    //## auto_generated
    cmdC_SP_C* get_cmdC_SP() const;
    
    //## auto_generated
    debc_SP_C* getDebc_SP() const;
    
    //## auto_generated
    debc_SP_C* get_debc_SP() const;
    
    //## auto_generated
    finc_SP_C* getFinc_SP() const;
    
    //## auto_generated
    finc_SP_C* get_finc_SP() const;
    
    //## auto_generated
    cmdVerrin_SP_C* getCmdVerrin_SP() const;
    
    //## auto_generated
    cmdVerrin_SP_C* get_cmdVerrin_SP() const;
    
    //## auto_generated
    mia_SP_C* getMia_SP() const;
    
    //## auto_generated
    mia_SP_C* get_mia_SP() const;
    
    //## auto_generated
    mib_SP_C* getMib_SP() const;
    
    //## auto_generated
    mib_SP_C* get_mib_SP() const;
    
    //## auto_generated
    dca_SP_C* getDca_SP() const;
    
    //## auto_generated
    dca_SP_C* get_dca_SP() const;
    
    //## auto_generated
    dcb_SP_C* getDcb_SP() const;
    
    //## auto_generated
    dcb_SP_C* get_dcb_SP() const;
    
    //## auto_generated
    int getCmdA() const;
    
    //## auto_generated
    int getCmdB() const;
    
    //## auto_generated
    int getCmdC() const;
    
    //## auto_generated
    int getCmdVerrin() const;
    
    //## auto_generated
    bool getConnected() const;
    
    //## auto_generated
    void setConnected(bool p_connected);
    
    //## auto_generated
    int getDca() const;
    
    //## auto_generated
    int getDcb() const;
    
    //## auto_generated
    int getDeba() const;
    
    //## auto_generated
    int getDebb() const;
    
    //## auto_generated
    int getDebc() const;
    
    //## auto_generated
    int getFina() const;
    
    //## auto_generated
    int getFinb() const;
    
    //## auto_generated
    int getFinc() const;
    
    //## auto_generated
    int getFlag() const;
    
    //## auto_generated
    void setFlag(int p_flag);
    
    //## auto_generated
    int getMia() const;
    
    //## auto_generated
    int getMib() const;
    
    //## auto_generated
    bool getOkToSend() const;
    
    //## auto_generated
    void setOkToSend(bool p_okToSend);
    
    //## auto_generated
    int getVersa() const;
    
    //## auto_generated
    int getVersb() const;
    
    //## auto_generated
    virtual bool startBehavior();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void initStatechart();
    
    //## auto_generated
    void cancelTimeouts();
    
    //## auto_generated
    bool cancelTimeout(const IOxfTimeout* arg);

private :

    //## auto_generated
    char* getBit() const;
    
    //## auto_generated
    void setBit(char* p_bit);
    
    //## auto_generated
    Entrees getEntrees() const;
    
    //## auto_generated
    void setEntrees(Entrees p_entrees);
    
    //## auto_generated
    long* getHandle() const;
    
    //## auto_generated
    void setHandle(long* p_handle);
    
    //## auto_generated
    int getId_maq_pc() const;
    
    //## auto_generated
    void setId_maq_pc(int p_id_maq_pc);
    
    //## auto_generated
    int getNum_pc() const;
    
    //## auto_generated
    void setNum_pc(int p_num_pc);
    
    //## auto_generated
    int getNum_tapis() const;
    
    //## auto_generated
    void setNum_tapis(int p_num_tapis);
    
    //## auto_generated
    Sorties getSorties() const;
    
    //## auto_generated
    void setSorties(Sorties p_sorties);
    
    //## auto_generated
    char* getTrame_entree() const;
    
    //## auto_generated
    void setTrame_entree(char* p_trame_entree);
    
    //## auto_generated
    char getTrame_sortie() const;
    
    //## auto_generated
    void setTrame_sortie(char p_trame_sortie);
    
    //## auto_generated
    int getVal() const;
    
    //## auto_generated
    void setVal(int p_val);

protected :

//#[ ignore
    connect_C connect;
    
    cmdA_SP_C cmdA_SP;
    
    deba_SP_C deba_SP;
    
    versa_SP_C versa_SP;
    
    fina_SP_C fina_SP;
    
    cmdB_SP_C cmdB_SP;
    
    debb_SP_C debb_SP;
    
    versb_SP_C versb_SP;
    
    finb_SP_C finb_SP;
    
    cmdC_SP_C cmdC_SP;
    
    debc_SP_C debc_SP;
    
    finc_SP_C finc_SP;
    
    cmdVerrin_SP_C cmdVerrin_SP;
    
    mia_SP_C mia_SP;
    
    mib_SP_C mib_SP;
    
    dca_SP_C dca_SP;
    
    dcb_SP_C dcb_SP;
//#]

public :

    // rootState:
    //## statechart_method
    inline bool rootState_IN() const;
    
    //## statechart_method
    virtual void rootState_entDef();
    
    //## statechart_method
    virtual IOxfReactive::TakeEventStatus rootState_processEvent();
    
    // state_6:
    //## statechart_method
    inline bool state_6_IN() const;
    
    // state_2:
    //## statechart_method
    inline bool state_2_IN() const;
    
    //## statechart_method
    void state_2_entDef();
    
    //## statechart_method
    void state_2_exit();
    
    // state_0:
    //## statechart_method
    inline bool state_0_IN() const;

protected :

//#[ ignore
    enum DriverTapis_Enum {
        OMNonState = 0,
        state_6 = 1,
        state_2 = 2,
        state_0 = 3
    };
    
    int rootState_subState;
    
    int rootState_active;
    
    IOxfTimeout* rootState_timeout;
    
    int state_2_subState;
    
    IOxfTimeout* state_2_timeout;
//#]
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedDriverTapis : public OMAnimatedIConnect {
    DECLARE_REACTIVE_META(DriverTapis, OMAnimatedDriverTapis)
    
    ////    Framework operations    ////
    
public :

    virtual void serializeAttributes(AOMSAttributes* aomsAttributes) const;
    
    virtual void serializeRelations(AOMSRelations* aomsRelations) const;
    
    //## statechart_method
    void rootState_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_6_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_2_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_0_serializeStates(AOMSState* aomsState) const;
};
//#]
#endif // _OMINSTRUMENT

inline bool DriverTapis::rootState_IN() const {
    return true;
}

inline bool DriverTapis::state_6_IN() const {
    return rootState_subState == state_6;
}

inline bool DriverTapis::state_2_IN() const {
    return rootState_subState == state_2;
}

inline bool DriverTapis::state_0_IN() const {
    return state_2_subState == state_0;
}

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\DriverTapis.h
*********************************************************************/
