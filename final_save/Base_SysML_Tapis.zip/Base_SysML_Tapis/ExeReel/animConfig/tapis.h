/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: tapis
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\tapis.h
*********************************************************************/

#ifndef tapis_H
#define tapis_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include "_DESIGN.h"
//## auto_generated
#include <oxf\omthread.h>
//## auto_generated
#include <oxf\omreactive.h>
//## auto_generated
#include <oxf\state.h>
//## auto_generated
#include <oxf\event.h>
//## class tapis
#include "intFlowInterface.h"
//## auto_generated
#include <oxf\omcollec.h>
//## package _DESIGN

//## class tapis
class tapis : public OMReactive, public intFlowInterface {
public :

//#[ ignore
    //## package _DESIGN
    class cmd_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        cmd_SP_C();
        
        //## auto_generated
        virtual ~cmd_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        //## auto_generated
        intFlowInterface* getOutBound();
        
        ////    Additional operations    ////
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterfaceAt(int i) const;
        
        //## auto_generated
        void addItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void removeItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
        
        //## auto_generated
        void clearItsIntFlowInterface();
        
        //## auto_generated
        int findItsIntFlowInterface(intFlowInterface* p_intFlowInterface) const;
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        OMCollection<intFlowInterface*> itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class deb_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        deb_SP_C();
        
        //## auto_generated
        virtual ~deb_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapis(tapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class vers_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        vers_SP_C();
        
        //## auto_generated
        virtual ~vers_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapis(tapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class fin_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        fin_SP_C();
        
        //## auto_generated
        virtual ~fin_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapis(tapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class debc_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        debc_SP_C();
        
        //## auto_generated
        virtual ~debc_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapis(tapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
    
    //## package _DESIGN
    class dc_SP_C : public intFlowInterface {
        ////    Constructors and destructors    ////
        
    public :
    
        //## auto_generated
        dc_SP_C();
        
        //## auto_generated
        virtual ~dc_SP_C();
        
        ////    Operations    ////
        
        //## auto_generated
        virtual void SetValue(int data, void * pCaller = NULL);
        
        //## auto_generated
        void connectTapis(tapis* part);
        
        //## auto_generated
        intFlowInterface* getItsIntFlowInterface();
        
        ////    Additional operations    ////
        
        //## auto_generated
        void setItsIntFlowInterface(intFlowInterface* p_intFlowInterface);
    
    protected :
    
        //## auto_generated
        void cleanUpRelations();
        
        ////    Attributes    ////
        
        int _p_;		//## attribute _p_
        
        ////    Relations and components    ////
        
        intFlowInterface* itsIntFlowInterface;		//## link itsIntFlowInterface
    };
//#]

    ////    Friends    ////
    
#ifdef _OMINSTRUMENT
    friend class OMAnimatedtapis;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    //## auto_generated
    tapis(IOxfActive* theActiveContext = 0);
    
    //## auto_generated
    ~tapis();
    
    ////    Operations    ////
    
//#[ ignore
    void SetValue(int data, void * pCaller = NULL);
    
    void setCmd(int p_cmd);
    
    void setDc(int p_dc);
    
    void setDeb(int p_deb);
    
    void setDebc(int p_debc);
    
    void setFin(int p_fin);
    
    void setVers(int p_vers);
//#]

    ////    Additional operations    ////
    
    //## auto_generated
    cmd_SP_C* getCmd_SP() const;
    
    //## auto_generated
    cmd_SP_C* get_cmd_SP() const;
    
    //## auto_generated
    deb_SP_C* getDeb_SP() const;
    
    //## auto_generated
    deb_SP_C* get_deb_SP() const;
    
    //## auto_generated
    vers_SP_C* getVers_SP() const;
    
    //## auto_generated
    vers_SP_C* get_vers_SP() const;
    
    //## auto_generated
    fin_SP_C* getFin_SP() const;
    
    //## auto_generated
    fin_SP_C* get_fin_SP() const;
    
    //## auto_generated
    debc_SP_C* getDebc_SP() const;
    
    //## auto_generated
    debc_SP_C* get_debc_SP() const;
    
    //## auto_generated
    dc_SP_C* getDc_SP() const;
    
    //## auto_generated
    dc_SP_C* get_dc_SP() const;
    
    //## auto_generated
    int getCmd() const;
    
    //## auto_generated
    int getDc() const;
    
    //## auto_generated
    int getDeb() const;
    
    //## auto_generated
    int getDebc() const;
    
    //## auto_generated
    int getFin() const;
    
    //## auto_generated
    int getVers() const;
    
    //## auto_generated
    virtual bool startBehavior();

protected :

    //## auto_generated
    void initRelations();
    
    //## auto_generated
    void initStatechart();
    
    ////    Attributes    ////
    
    int cmd;		//## attribute cmd
    
    int dc;		//## attribute dc
    
    int deb;		//## attribute deb
    
    int debc;		//## attribute debc
    
    int fin;		//## attribute fin
    
    int vers;		//## attribute vers
    
    ////    Relations and components    ////
    
//#[ ignore
    cmd_SP_C cmd_SP;
    
    deb_SP_C deb_SP;
    
    vers_SP_C vers_SP;
    
    fin_SP_C fin_SP;
    
    debc_SP_C debc_SP;
    
    dc_SP_C dc_SP;
//#]

    ////    Framework operations    ////

public :

    // rootState:
    //## statechart_method
    inline bool rootState_IN() const;
    
    //## statechart_method
    virtual void rootState_entDef();
    
    //## statechart_method
    virtual IOxfReactive::TakeEventStatus rootState_processEvent();
    
    // state_4:
    //## statechart_method
    inline bool state_4_IN() const;
    
    // state_3:
    //## statechart_method
    inline bool state_3_IN() const;
    
    // state_2:
    //## statechart_method
    inline bool state_2_IN() const;
    
    // state_1:
    //## statechart_method
    inline bool state_1_IN() const;
    
    // state_0:
    //## statechart_method
    inline bool state_0_IN() const;
    
    ////    Framework    ////

protected :

//#[ ignore
    enum tapis_Enum {
        OMNonState = 0,
        state_4 = 1,
        state_3 = 2,
        state_2 = 3,
        state_1 = 4,
        state_0 = 5
    };
    
    int rootState_subState;
    
    int rootState_active;
//#]
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedtapis : virtual public AOMInstance {
    DECLARE_REACTIVE_META(tapis, OMAnimatedtapis)
    
    ////    Framework operations    ////
    
public :

    virtual void serializeAttributes(AOMSAttributes* aomsAttributes) const;
    
    virtual void serializeRelations(AOMSRelations* aomsRelations) const;
    
    //## statechart_method
    void rootState_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_4_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_3_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_2_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_1_serializeStates(AOMSState* aomsState) const;
    
    //## statechart_method
    void state_0_serializeStates(AOMSState* aomsState) const;
};
//#]
#endif // _OMINSTRUMENT

inline bool tapis::rootState_IN() const {
    return true;
}

inline bool tapis::state_4_IN() const {
    return rootState_subState == state_4;
}

inline bool tapis::state_3_IN() const {
    return rootState_subState == state_3;
}

inline bool tapis::state_2_IN() const {
    return rootState_subState == state_2;
}

inline bool tapis::state_1_IN() const {
    return rootState_subState == state_1;
}

inline bool tapis::state_0_IN() const {
    return rootState_subState == state_0;
}

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\tapis.h
*********************************************************************/
