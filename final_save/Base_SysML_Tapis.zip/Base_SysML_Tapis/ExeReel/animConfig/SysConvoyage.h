/*********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: SysConvoyage
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\SysConvoyage.h
*********************************************************************/

#ifndef SysConvoyage_H
#define SysConvoyage_H

//## auto_generated
#include <oxf\oxf.h>
//## auto_generated
#include <..\Profiles\SysML\SIDefinitions.h>
//## auto_generated
#include <aom\aom.h>
//## auto_generated
#include "..\..\Pci7841.h"
//## auto_generated
#include "..\..\resource.h"
//## auto_generated
#include "..\..\Typedef.h"
//## auto_generated
#include <oxf\omthread.h>
//## auto_generated
#include <oxf\omreactive.h>
//## auto_generated
#include <oxf\state.h>
//## auto_generated
#include <oxf\event.h>
//## classInstance itsDriverTapis
#include "DriverTapis.h"
//## auto_generated
#include "_DESIGN.h"
//## classInstance itsTapis
#include "tapis.h"
//## classInstance itsTapisC
#include "tapisC.h"
//## classInstance itsVerrin
#include "Verrin.h"
//## package _DESIGN

//## class SysConvoyage
class SysConvoyage : public OMReactive {
    ////    Friends    ////
    
public :

#ifdef _OMINSTRUMENT
    friend class OMAnimatedSysConvoyage;
#endif // _OMINSTRUMENT

    ////    Constructors and destructors    ////
    
    ////    Additional operations    ////
    
    ////    Relations and components    ////

protected :

    DriverTapis itsDriverTapis;		//## classInstance itsDriverTapis
    
    ////    Framework operations    ////

public :

    //## auto_generated
    SysConvoyage(IOxfActive* theActiveContext = 0);
    
    //## auto_generated
    ~SysConvoyage();
    
    //## auto_generated
    DriverTapis* getItsDriverTapis() const;
    
    //## auto_generated
    tapis* getItsTapis() const;
    
    //## auto_generated
    tapisC* getItsTapisC() const;
    
    //## auto_generated
    tapis* getItsTapis_1() const;
    
    //## auto_generated
    Verrin* getItsVerrin() const;
    
    //## auto_generated
    virtual bool startBehavior();

protected :

    //## auto_generated
    void initRelations();
    
    tapis itsTapis;		//## classInstance itsTapis
    
    tapisC itsTapisC;		//## classInstance itsTapisC
    
    tapis itsTapis_1;		//## classInstance itsTapis_1
    
    Verrin itsVerrin;		//## classInstance itsVerrin

public :

    //## auto_generated
    void setActiveContext(IOxfActive* theActiveContext, bool activeInstance);
    
    //## auto_generated
    virtual void destroy();
};

#ifdef _OMINSTRUMENT
//#[ ignore
class OMAnimatedSysConvoyage : virtual public AOMInstance {
    DECLARE_META(SysConvoyage, OMAnimatedSysConvoyage)
    
    ////    Framework operations    ////
    
public :

    virtual void serializeRelations(AOMSRelations* aomsRelations) const;
};
//#]
#endif // _OMINSTRUMENT

#endif
/*********************************************************************
	File Path	: ExeReel\animConfig\SysConvoyage.h
*********************************************************************/
