/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: animConfig
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\MainExeReel.cpp
*********************************************************************/

//## auto_generated
#include "MainExeReel.h"
//## auto_generated
#include "SysConvoyage.h"
int main(int argc, char* argv[]) {
    int status = 0;
    if(OXF::initialize(argc, argv, 6423))
        {
            SysConvoyage * p_SysConvoyage;
            p_SysConvoyage = new SysConvoyage;
            p_SysConvoyage->startBehavior();
            //#[ configuration ExeReel::animConfig 
            //#]
            OXF::start();
            delete p_SysConvoyage;
            status = 0;
        }
    else
        {
            status = 1;
        }
    return status;
}

/*********************************************************************
	File Path	: ExeReel\animConfig\MainExeReel.cpp
*********************************************************************/
