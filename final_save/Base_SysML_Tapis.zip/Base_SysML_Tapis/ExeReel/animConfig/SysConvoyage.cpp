/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: SysConvoyage
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\SysConvoyage.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "SysConvoyage.h"
//#[ ignore
#define _DESIGN_SysConvoyage_SysConvoyage_SERIALIZE OM_NO_OP
//#]

//## package _DESIGN

//## class SysConvoyage
SysConvoyage::SysConvoyage(IOxfActive* theActiveContext) {
    NOTIFY_REACTIVE_CONSTRUCTOR(SysConvoyage, SysConvoyage(), 0, _DESIGN_SysConvoyage_SysConvoyage_SERIALIZE);
    setActiveContext(theActiveContext, false);
    {
        {
            itsDriverTapis.setShouldDelete(false);
        }
        {
            itsTapis.setShouldDelete(false);
        }
        {
            itsTapis_1.setShouldDelete(false);
        }
        {
            itsTapisC.setShouldDelete(false);
        }
        {
            itsVerrin.setShouldDelete(false);
        }
    }
    initRelations();
}

SysConvoyage::~SysConvoyage() {
    NOTIFY_DESTRUCTOR(~SysConvoyage, true);
}

DriverTapis* SysConvoyage::getItsDriverTapis() const {
    return (DriverTapis*) &itsDriverTapis;
}

tapis* SysConvoyage::getItsTapis() const {
    return (tapis*) &itsTapis;
}

tapisC* SysConvoyage::getItsTapisC() const {
    return (tapisC*) &itsTapisC;
}

tapis* SysConvoyage::getItsTapis_1() const {
    return (tapis*) &itsTapis_1;
}

Verrin* SysConvoyage::getItsVerrin() const {
    return (Verrin*) &itsVerrin;
}

bool SysConvoyage::startBehavior() {
    bool done = true;
    done &= itsDriverTapis.startBehavior();
    done &= itsTapis.startBehavior();
    done &= itsTapisC.startBehavior();
    done &= itsTapis_1.startBehavior();
    done &= itsVerrin.startBehavior();
    done &= OMReactive::startBehavior();
    return done;
}

void SysConvoyage::initRelations() {
    {
        
        itsTapis.get_cmd_SP()->addItsIntFlowInterface(itsDriverTapis.get_cmdA_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsTapis_1.get_cmd_SP()->addItsIntFlowInterface(itsDriverTapis.get_cmdB_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_deba_SP()->setItsIntFlowInterface(itsTapis.get_deb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_debb_SP()->setItsIntFlowInterface(itsTapis_1.get_deb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_versa_SP()->addItsIntFlowInterface(itsTapis.get_vers_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_versb_SP()->addItsIntFlowInterface(itsTapis_1.get_vers_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_finb_SP()->addItsIntFlowInterface(itsTapis_1.get_fin_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_fina_SP()->addItsIntFlowInterface(itsTapis.get_fin_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_debc_SP()->addItsIntFlowInterface(itsTapis_1.get_debc_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_debc_SP()->addItsIntFlowInterface(itsTapis.get_debc_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_dcb_SP()->setItsIntFlowInterface(itsTapis_1.get_dc_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_dca_SP()->setItsIntFlowInterface(itsTapis.get_dc_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsVerrin.get_cmdVerrin_SP()->setItsIntFlowInterface(itsDriverTapis.get_cmdVerrin_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_debc_SP()->addItsIntFlowInterface(itsVerrin.get_debc_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_mia_SP()->setItsIntFlowInterface(itsVerrin.get_mia_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_versa_SP()->addItsIntFlowInterface(itsVerrin.get_versa_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_mib_SP()->setItsIntFlowInterface(itsVerrin.get_mib_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_versb_SP()->addItsIntFlowInterface(itsVerrin.get_versb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_finb_SP()->addItsIntFlowInterface(itsVerrin.get_finb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_fina_SP()->addItsIntFlowInterface(itsVerrin.get_fina_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsTapisC.get_cmd_SP()->setItsIntFlowInterface(itsDriverTapis.get_cmdC_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_debc_SP()->addItsIntFlowInterface(itsTapisC.get_deb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_versa_SP()->addItsIntFlowInterface(itsTapisC.get_versa_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_finc_SP()->setItsIntFlowInterface(itsTapisC.get_fin_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_versb_SP()->addItsIntFlowInterface(itsTapisC.get_versb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_finb_SP()->addItsIntFlowInterface(itsTapisC.get_finb_SP()->getItsIntFlowInterface());
        
    }
    {
        
        itsDriverTapis.get_fina_SP()->addItsIntFlowInterface(itsTapisC.get_fina_SP()->getItsIntFlowInterface());
        
    }
}

void SysConvoyage::setActiveContext(IOxfActive* theActiveContext, bool activeInstance) {
    OMReactive::setActiveContext(theActiveContext, activeInstance);
    {
        itsTapis.setActiveContext(theActiveContext, false);
        itsTapis_1.setActiveContext(theActiveContext, false);
        itsTapisC.setActiveContext(theActiveContext, false);
        itsVerrin.setActiveContext(theActiveContext, false);
    }
}

void SysConvoyage::destroy() {
    itsDriverTapis.destroy();
    itsTapis.destroy();
    itsTapisC.destroy();
    itsTapis_1.destroy();
    itsVerrin.destroy();
    OMReactive::destroy();
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimatedSysConvoyage::serializeRelations(AOMSRelations* aomsRelations) const {
    aomsRelations->addRelation("itsDriverTapis", true, true);
    aomsRelations->ADD_ITEM(&myReal->itsDriverTapis);
    aomsRelations->addRelation("itsTapis", true, true);
    aomsRelations->ADD_ITEM(&myReal->itsTapis);
    aomsRelations->addRelation("itsTapis_1", true, true);
    aomsRelations->ADD_ITEM(&myReal->itsTapis_1);
    aomsRelations->addRelation("itsTapisC", true, true);
    aomsRelations->ADD_ITEM(&myReal->itsTapisC);
    aomsRelations->addRelation("itsVerrin", true, true);
    aomsRelations->ADD_ITEM(&myReal->itsVerrin);
}
//#]

IMPLEMENT_REACTIVE_META_SIMPLE_P(SysConvoyage, _DESIGN, _DESIGN, false, OMAnimatedSysConvoyage)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\SysConvoyage.cpp
*********************************************************************/
