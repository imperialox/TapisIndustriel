/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: DriverTapisPkg
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\DriverTapisPkg.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "DriverTapisPkg.h"
//## auto_generated
#include "DriverTapis.h"
//## auto_generated
#include "IConnect.h"
//#[ ignore
#define evConnect_SERIALIZE OM_NO_OP

#define evConnect_UNSERIALIZE OM_NO_OP

#define evConnect_CONSTRUCTOR evConnect()
//#]

//## package DriverTapisPkg


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(DriverTapisPkg, DriverTapisPkg)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

//## event evConnect()
evConnect::evConnect() {
    NOTIFY_EVENT_CONSTRUCTOR(evConnect)
    setId(evConnect_DriverTapisPkg_id);
}

bool evConnect::isTypeOf(const short id) const {
    return (evConnect_DriverTapisPkg_id==id);
}

IMPLEMENT_META_EVENT_P(evConnect, DriverTapisPkg, DriverTapisPkg, evConnect())

/*********************************************************************
	File Path	: ExeReel\animConfig\DriverTapisPkg.cpp
*********************************************************************/
