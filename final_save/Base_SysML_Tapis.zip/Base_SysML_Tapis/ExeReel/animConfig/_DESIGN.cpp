/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: _DESIGN
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\_DESIGN.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX
//#]

//## auto_generated
#include "_DESIGN.h"
//## auto_generated
#include "SysConvoyage.h"
//## auto_generated
#include "tapis.h"
//## auto_generated
#include "tapisC.h"
//## auto_generated
#include "Verrin.h"
//#[ ignore
#define chDeb_SERIALIZE OM_NO_OP

#define chDeb_UNSERIALIZE OM_NO_OP

#define chDeb_CONSTRUCTOR chDeb()

#define chVers_SERIALIZE OM_NO_OP

#define chVers_UNSERIALIZE OM_NO_OP

#define chVers_CONSTRUCTOR chVers()

#define chFin_SERIALIZE OM_NO_OP

#define chFin_UNSERIALIZE OM_NO_OP

#define chFin_CONSTRUCTOR chFin()

#define chMia_SERIALIZE OM_NO_OP

#define chMia_UNSERIALIZE OM_NO_OP

#define chMia_CONSTRUCTOR chMia()

#define chVersa_SERIALIZE OM_NO_OP

#define chVersa_UNSERIALIZE OM_NO_OP

#define chVersa_CONSTRUCTOR chVersa()

#define chDebc_SERIALIZE OM_NO_OP

#define chDebc_UNSERIALIZE OM_NO_OP

#define chDebc_CONSTRUCTOR chDebc()

#define chMib_SERIALIZE OM_NO_OP

#define chMib_UNSERIALIZE OM_NO_OP

#define chMib_CONSTRUCTOR chMib()

#define chVersb_SERIALIZE OM_NO_OP

#define chVersb_UNSERIALIZE OM_NO_OP

#define chVersb_CONSTRUCTOR chVersb()

#define chFinb_SERIALIZE OM_NO_OP

#define chFinb_UNSERIALIZE OM_NO_OP

#define chFinb_CONSTRUCTOR chFinb()

#define chFina_SERIALIZE OM_NO_OP

#define chFina_UNSERIALIZE OM_NO_OP

#define chFina_CONSTRUCTOR chFina()

#define chDc_SERIALIZE OM_NO_OP

#define chDc_UNSERIALIZE OM_NO_OP

#define chDc_CONSTRUCTOR chDc()
//#]

//## package _DESIGN


#ifdef _OMINSTRUMENT
static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */);

IMPLEMENT_META_PACKAGE(_DESIGN, _DESIGN)

static void serializeGlobalVars(AOMSAttributes* /* aomsAttributes */) {
}
#endif // _OMINSTRUMENT

//## event chDeb()
chDeb::chDeb() {
    NOTIFY_EVENT_CONSTRUCTOR(chDeb)
    setId(chDeb__DESIGN_id);
}

bool chDeb::isTypeOf(const short id) const {
    return (chDeb__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chDeb, _DESIGN, _DESIGN, chDeb())

//## event chVers()
chVers::chVers() {
    NOTIFY_EVENT_CONSTRUCTOR(chVers)
    setId(chVers__DESIGN_id);
}

bool chVers::isTypeOf(const short id) const {
    return (chVers__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chVers, _DESIGN, _DESIGN, chVers())

//## event chFin()
chFin::chFin() {
    NOTIFY_EVENT_CONSTRUCTOR(chFin)
    setId(chFin__DESIGN_id);
}

bool chFin::isTypeOf(const short id) const {
    return (chFin__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chFin, _DESIGN, _DESIGN, chFin())

//## event chMia()
chMia::chMia() {
    NOTIFY_EVENT_CONSTRUCTOR(chMia)
    setId(chMia__DESIGN_id);
}

bool chMia::isTypeOf(const short id) const {
    return (chMia__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chMia, _DESIGN, _DESIGN, chMia())

//## event chVersa()
chVersa::chVersa() {
    NOTIFY_EVENT_CONSTRUCTOR(chVersa)
    setId(chVersa__DESIGN_id);
}

bool chVersa::isTypeOf(const short id) const {
    return (chVersa__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chVersa, _DESIGN, _DESIGN, chVersa())

//## event chDebc()
chDebc::chDebc() {
    NOTIFY_EVENT_CONSTRUCTOR(chDebc)
    setId(chDebc__DESIGN_id);
}

bool chDebc::isTypeOf(const short id) const {
    return (chDebc__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chDebc, _DESIGN, _DESIGN, chDebc())

//## event chMib()
chMib::chMib() {
    NOTIFY_EVENT_CONSTRUCTOR(chMib)
    setId(chMib__DESIGN_id);
}

bool chMib::isTypeOf(const short id) const {
    return (chMib__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chMib, _DESIGN, _DESIGN, chMib())

//## event chVersb()
chVersb::chVersb() {
    NOTIFY_EVENT_CONSTRUCTOR(chVersb)
    setId(chVersb__DESIGN_id);
}

bool chVersb::isTypeOf(const short id) const {
    return (chVersb__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chVersb, _DESIGN, _DESIGN, chVersb())

//## event chFinb()
chFinb::chFinb() {
    NOTIFY_EVENT_CONSTRUCTOR(chFinb)
    setId(chFinb__DESIGN_id);
}

bool chFinb::isTypeOf(const short id) const {
    return (chFinb__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chFinb, _DESIGN, _DESIGN, chFinb())

//## event chFina()
chFina::chFina() {
    NOTIFY_EVENT_CONSTRUCTOR(chFina)
    setId(chFina__DESIGN_id);
}

bool chFina::isTypeOf(const short id) const {
    return (chFina__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chFina, _DESIGN, _DESIGN, chFina())

//## event chDc()
chDc::chDc() {
    NOTIFY_EVENT_CONSTRUCTOR(chDc)
    setId(chDc__DESIGN_id);
}

bool chDc::isTypeOf(const short id) const {
    return (chDc__DESIGN_id==id);
}

IMPLEMENT_META_EVENT_P(chDc, _DESIGN, _DESIGN, chDc())

/*********************************************************************
	File Path	: ExeReel\animConfig\_DESIGN.cpp
*********************************************************************/
