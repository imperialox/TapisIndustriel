/********************************************************************
	Rhapsody	: 9.0 
	Login		: mezouami
	Component	: ExeReel 
	Configuration 	: animConfig
	Model Element	: Verrin
//!	Generated Date	: Wed, 11, Jan 2023  
	File Path	: ExeReel\animConfig\Verrin.cpp
*********************************************************************/

//#[ ignore
#define NAMESPACE_PREFIX

#define _OMSTATECHART_ANIMATED
//#]

//## auto_generated
#include "Verrin.h"
//#[ ignore
#define _DESIGN_Verrin_Verrin_SERIALIZE OM_NO_OP
//#]

//## package _DESIGN

//## class Verrin
//#[ ignore
Verrin::cmdVerrin_SP_C::cmdVerrin_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::cmdVerrin_SP_C::~cmdVerrin_SP_C() {
    cleanUpRelations();
}

void Verrin::cmdVerrin_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,pCaller);
    }
    
}

intFlowInterface* Verrin::cmdVerrin_SP_C::getItsIntFlowInterface() {
    return this;
}

intFlowInterface* Verrin::cmdVerrin_SP_C::getOutBound() {
    return this;
}

void Verrin::cmdVerrin_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::cmdVerrin_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::debc_SP_C::debc_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::debc_SP_C::~debc_SP_C() {
    cleanUpRelations();
}

void Verrin::debc_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::debc_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::debc_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::debc_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::debc_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::mia_SP_C::mia_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::mia_SP_C::~mia_SP_C() {
    cleanUpRelations();
}

void Verrin::mia_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::mia_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::mia_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::mia_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::mia_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::versa_SP_C::versa_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::versa_SP_C::~versa_SP_C() {
    cleanUpRelations();
}

void Verrin::versa_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::versa_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::versa_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::versa_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::versa_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::mib_SP_C::mib_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::mib_SP_C::~mib_SP_C() {
    cleanUpRelations();
}

void Verrin::mib_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::mib_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::mib_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::mib_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::mib_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::versb_SP_C::versb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::versb_SP_C::~versb_SP_C() {
    cleanUpRelations();
}

void Verrin::versb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::versb_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::versb_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::versb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::versb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::finb_SP_C::finb_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::finb_SP_C::~finb_SP_C() {
    cleanUpRelations();
}

void Verrin::finb_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::finb_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::finb_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::finb_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::finb_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}

Verrin::fina_SP_C::fina_SP_C() : _p_(0) {
    itsIntFlowInterface = NULL;
}

Verrin::fina_SP_C::~fina_SP_C() {
    cleanUpRelations();
}

void Verrin::fina_SP_C::SetValue(int data, void * pCaller) {
    
    if (itsIntFlowInterface != NULL) {
        itsIntFlowInterface->SetValue(data,this);
    }
    
}

void Verrin::fina_SP_C::connectVerrin(Verrin* part) {
    setItsIntFlowInterface(part);
    
}

intFlowInterface* Verrin::fina_SP_C::getItsIntFlowInterface() {
    return this;
}

void Verrin::fina_SP_C::setItsIntFlowInterface(intFlowInterface* p_intFlowInterface) {
    itsIntFlowInterface = p_intFlowInterface;
}

void Verrin::fina_SP_C::cleanUpRelations() {
    if(itsIntFlowInterface != NULL)
        {
            itsIntFlowInterface = NULL;
        }
}
//#]

Verrin::Verrin(IOxfActive* theActiveContext) : cmdVerrin(0), debc(0), fina(0), finb(0), mia(0), mib(0), versa(0), versb(0) {
    NOTIFY_REACTIVE_CONSTRUCTOR(Verrin, Verrin(), 0, _DESIGN_Verrin_Verrin_SERIALIZE);
    setActiveContext(theActiveContext, false);
    initRelations();
    initStatechart();
}

Verrin::~Verrin() {
    NOTIFY_DESTRUCTOR(~Verrin, true);
    cancelTimeouts();
}

//#[ ignore
void Verrin::SetValue(int data, void * pCaller) {
    if (pCaller == (void *)get_debc_SP()) {
        setDebc(data);
    }
    
    if (pCaller == (void *)get_mia_SP()) {
        setMia(data);
    }
    
    if (pCaller == (void *)get_versa_SP()) {
        setVersa(data);
    }
    
    if (pCaller == (void *)get_mib_SP()) {
        setMib(data);
    }
    
    if (pCaller == (void *)get_versb_SP()) {
        setVersb(data);
    }
    
    if (pCaller == (void *)get_finb_SP()) {
        setFinb(data);
    }
    
    if (pCaller == (void *)get_fina_SP()) {
        setFina(data);
    }
}

void Verrin::setCmdVerrin(int p_cmdVerrin) {
    if (cmdVerrin != p_cmdVerrin)  {
        cmdVerrin = p_cmdVerrin;
        FLOW_DATA_SEND(cmdVerrin, cmdVerrin_SP, SetValue, x2String);
    }
}

void Verrin::setDebc(int p_debc) {
    if (debc != p_debc) {
        debc = p_debc;
        FLOW_DATA_RECEIVE("debc", debc, x2String);
        GEN(chDebc);
    }
    
}

void Verrin::setFina(int p_fina) {
    if (fina != p_fina) {
        fina = p_fina;
        FLOW_DATA_RECEIVE("fina", fina, x2String);
        GEN(chFina);
    }
    
}

void Verrin::setFinb(int p_finb) {
    if (finb != p_finb) {
        finb = p_finb;
        FLOW_DATA_RECEIVE("finb", finb, x2String);
        GEN(chFinb);
    }
    
}

void Verrin::setMia(int p_mia) {
    if (mia != p_mia) {
        mia = p_mia;
        FLOW_DATA_RECEIVE("mia", mia, x2String);
        GEN(chMia);
    }
    
}

void Verrin::setMib(int p_mib) {
    if (mib != p_mib) {
        mib = p_mib;
        FLOW_DATA_RECEIVE("mib", mib, x2String);
        GEN(chMib);
    }
    
}

void Verrin::setVersa(int p_versa) {
    if (versa != p_versa) {
        versa = p_versa;
        FLOW_DATA_RECEIVE("versa", versa, x2String);
        GEN(chVersa);
    }
    
}

void Verrin::setVersb(int p_versb) {
    if (versb != p_versb) {
        versb = p_versb;
        FLOW_DATA_RECEIVE("versb", versb, x2String);
        GEN(chVersb);
    }
    
}
//#]

Verrin::cmdVerrin_SP_C* Verrin::getCmdVerrin_SP() const {
    return (Verrin::cmdVerrin_SP_C*) &cmdVerrin_SP;
}

Verrin::cmdVerrin_SP_C* Verrin::get_cmdVerrin_SP() const {
    return (Verrin::cmdVerrin_SP_C*) &cmdVerrin_SP;
}

Verrin::debc_SP_C* Verrin::getDebc_SP() const {
    return (Verrin::debc_SP_C*) &debc_SP;
}

Verrin::debc_SP_C* Verrin::get_debc_SP() const {
    return (Verrin::debc_SP_C*) &debc_SP;
}

Verrin::mia_SP_C* Verrin::getMia_SP() const {
    return (Verrin::mia_SP_C*) &mia_SP;
}

Verrin::mia_SP_C* Verrin::get_mia_SP() const {
    return (Verrin::mia_SP_C*) &mia_SP;
}

Verrin::versa_SP_C* Verrin::getVersa_SP() const {
    return (Verrin::versa_SP_C*) &versa_SP;
}

Verrin::versa_SP_C* Verrin::get_versa_SP() const {
    return (Verrin::versa_SP_C*) &versa_SP;
}

Verrin::mib_SP_C* Verrin::getMib_SP() const {
    return (Verrin::mib_SP_C*) &mib_SP;
}

Verrin::mib_SP_C* Verrin::get_mib_SP() const {
    return (Verrin::mib_SP_C*) &mib_SP;
}

Verrin::versb_SP_C* Verrin::getVersb_SP() const {
    return (Verrin::versb_SP_C*) &versb_SP;
}

Verrin::versb_SP_C* Verrin::get_versb_SP() const {
    return (Verrin::versb_SP_C*) &versb_SP;
}

Verrin::finb_SP_C* Verrin::getFinb_SP() const {
    return (Verrin::finb_SP_C*) &finb_SP;
}

Verrin::finb_SP_C* Verrin::get_finb_SP() const {
    return (Verrin::finb_SP_C*) &finb_SP;
}

Verrin::fina_SP_C* Verrin::getFina_SP() const {
    return (Verrin::fina_SP_C*) &fina_SP;
}

Verrin::fina_SP_C* Verrin::get_fina_SP() const {
    return (Verrin::fina_SP_C*) &fina_SP;
}

int Verrin::getCmdVerrin() const {
    return cmdVerrin;
}

int Verrin::getDebc() const {
    return debc;
}

int Verrin::getFina() const {
    return fina;
}

int Verrin::getFinb() const {
    return finb;
}

int Verrin::getMia() const {
    return mia;
}

int Verrin::getMib() const {
    return mib;
}

int Verrin::getVersa() const {
    return versa;
}

int Verrin::getVersb() const {
    return versb;
}

bool Verrin::startBehavior() {
    bool done = false;
    done = OMReactive::startBehavior();
    return done;
}

void Verrin::initRelations() {
    if (get_debc_SP() != NULL) {
        get_debc_SP()->connectVerrin(this);
    }
    if (get_mia_SP() != NULL) {
        get_mia_SP()->connectVerrin(this);
    }
    if (get_versa_SP() != NULL) {
        get_versa_SP()->connectVerrin(this);
    }
    if (get_mib_SP() != NULL) {
        get_mib_SP()->connectVerrin(this);
    }
    if (get_versb_SP() != NULL) {
        get_versb_SP()->connectVerrin(this);
    }
    if (get_finb_SP() != NULL) {
        get_finb_SP()->connectVerrin(this);
    }
    if (get_fina_SP() != NULL) {
        get_fina_SP()->connectVerrin(this);
    }
}

void Verrin::initStatechart() {
    rootState_subState = OMNonState;
    rootState_active = OMNonState;
    rootState_timeout = NULL;
}

void Verrin::cancelTimeouts() {
    cancel(rootState_timeout);
}

bool Verrin::cancelTimeout(const IOxfTimeout* arg) {
    bool res = false;
    if(rootState_timeout == arg)
        {
            rootState_timeout = NULL;
            res = true;
        }
    return res;
}

void Verrin::rootState_entDef() {
    {
        NOTIFY_STATE_ENTERED("ROOT");
        NOTIFY_TRANSITION_STARTED("0");
        NOTIFY_STATE_ENTERED("ROOT.state_0");
        rootState_subState = state_0;
        rootState_active = state_0;
        NOTIFY_TRANSITION_TERMINATED("0");
    }
}

IOxfReactive::TakeEventStatus Verrin::rootState_processEvent() {
    IOxfReactive::TakeEventStatus res = eventNotConsumed;
    switch (rootState_active) {
        // State state_0
        case state_0:
        {
            if(IS_EVENT_TYPE_OF(chMia__DESIGN_id))
                {
                    //## transition 1 
                    if(mia==1)
                        {
                            NOTIFY_TRANSITION_STARTED("1");
                            NOTIFY_STATE_EXITED("ROOT.state_0");
                            //#[ transition 1 
                            setCmdVerrin(1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_1");
                            rootState_subState = state_1;
                            rootState_active = state_1;
                            NOTIFY_TRANSITION_TERMINATED("1");
                            res = eventConsumed;
                        }
                }
            else if(IS_EVENT_TYPE_OF(chMib__DESIGN_id))
                {
                    //## transition 6 
                    if(mib==1)
                        {
                            NOTIFY_TRANSITION_STARTED("6");
                            NOTIFY_STATE_EXITED("ROOT.state_0");
                            NOTIFY_STATE_ENTERED("ROOT.state_7");
                            rootState_subState = state_7;
                            rootState_active = state_7;
                            NOTIFY_TRANSITION_TERMINATED("6");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_1
        case state_1:
        {
            if(IS_EVENT_TYPE_OF(chFina__DESIGN_id))
                {
                    //## transition 2 
                    if(fina==1)
                        {
                            NOTIFY_TRANSITION_STARTED("2");
                            NOTIFY_STATE_EXITED("ROOT.state_1");
                            //#[ transition 2 
                            setCmdVerrin(0);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_2");
                            rootState_subState = state_2;
                            rootState_active = state_2;
                            rootState_timeout = scheduleTimeout(2000, "ROOT.state_2");
                            NOTIFY_TRANSITION_TERMINATED("2");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_2
        case state_2:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == rootState_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("3");
                            cancel(rootState_timeout);
                            NOTIFY_STATE_EXITED("ROOT.state_2");
                            NOTIFY_STATE_ENTERED("ROOT.state_3");
                            rootState_subState = state_3;
                            rootState_active = state_3;
                            NOTIFY_TRANSITION_TERMINATED("3");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_3
        case state_3:
        {
            if(IS_EVENT_TYPE_OF(chDebc__DESIGN_id))
                {
                    //## transition 4 
                    if(debc==1)
                        {
                            NOTIFY_TRANSITION_STARTED("4");
                            NOTIFY_STATE_EXITED("ROOT.state_3");
                            //#[ transition 4 
                            setCmdVerrin(1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_4");
                            rootState_subState = state_4;
                            rootState_active = state_4;
                            NOTIFY_TRANSITION_TERMINATED("4");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_4
        case state_4:
        {
            if(IS_EVENT_TYPE_OF(chMia__DESIGN_id))
                {
                    NOTIFY_TRANSITION_STARTED("5");
                    NOTIFY_STATE_EXITED("ROOT.state_4");
                    //#[ transition 5 
                    setCmdVerrin(0);
                    //#]
                    NOTIFY_STATE_ENTERED("ROOT.state_0");
                    rootState_subState = state_0;
                    rootState_active = state_0;
                    NOTIFY_TRANSITION_TERMINATED("5");
                    res = eventConsumed;
                }
            
        }
        break;
        // State state_7
        case state_7:
        {
            if(IS_EVENT_TYPE_OF(chFinb__DESIGN_id))
                {
                    //## transition 7 
                    if(finb==1)
                        {
                            NOTIFY_TRANSITION_STARTED("7");
                            NOTIFY_STATE_EXITED("ROOT.state_7");
                            //#[ transition 7 
                            setCmdVerrin(1);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_8");
                            rootState_subState = state_8;
                            rootState_active = state_8;
                            rootState_timeout = scheduleTimeout(2000, "ROOT.state_8");
                            NOTIFY_TRANSITION_TERMINATED("7");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_8
        case state_8:
        {
            if(IS_EVENT_TYPE_OF(OMTimeoutEventId))
                {
                    if(getCurrentEvent() == rootState_timeout)
                        {
                            NOTIFY_TRANSITION_STARTED("8");
                            cancel(rootState_timeout);
                            NOTIFY_STATE_EXITED("ROOT.state_8");
                            NOTIFY_STATE_ENTERED("ROOT.state_9");
                            rootState_subState = state_9;
                            rootState_active = state_9;
                            NOTIFY_TRANSITION_TERMINATED("8");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_9
        case state_9:
        {
            if(IS_EVENT_TYPE_OF(chDebc__DESIGN_id))
                {
                    //## transition 9 
                    if(debc==1)
                        {
                            NOTIFY_TRANSITION_STARTED("9");
                            NOTIFY_STATE_EXITED("ROOT.state_9");
                            //#[ transition 9 
                            setCmdVerrin(0);
                            //#]
                            NOTIFY_STATE_ENTERED("ROOT.state_10");
                            rootState_subState = state_10;
                            rootState_active = state_10;
                            NOTIFY_TRANSITION_TERMINATED("9");
                            res = eventConsumed;
                        }
                }
            
        }
        break;
        // State state_10
        case state_10:
        {
            if(IS_EVENT_TYPE_OF(chMib__DESIGN_id))
                {
                    NOTIFY_TRANSITION_STARTED("10");
                    NOTIFY_STATE_EXITED("ROOT.state_10");
                    NOTIFY_STATE_ENTERED("ROOT.state_0");
                    rootState_subState = state_0;
                    rootState_active = state_0;
                    NOTIFY_TRANSITION_TERMINATED("10");
                    res = eventConsumed;
                }
            
        }
        break;
        default:
            break;
    }
    return res;
}

#ifdef _OMINSTRUMENT
//#[ ignore
void OMAnimatedVerrin::serializeAttributes(AOMSAttributes* aomsAttributes) const {
    aomsAttributes->addAttribute("cmdVerrin", x2String(myReal->cmdVerrin));
    aomsAttributes->addAttribute("debc", x2String(myReal->debc));
    aomsAttributes->addAttribute("mia", x2String(myReal->mia));
    aomsAttributes->addAttribute("versa", x2String(myReal->versa));
    aomsAttributes->addAttribute("mib", x2String(myReal->mib));
    aomsAttributes->addAttribute("versb", x2String(myReal->versb));
    aomsAttributes->addAttribute("finb", x2String(myReal->finb));
    aomsAttributes->addAttribute("fina", x2String(myReal->fina));
}

void OMAnimatedVerrin::serializeRelations(AOMSRelations* aomsRelations) const {
}

void OMAnimatedVerrin::rootState_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT");
    switch (myReal->rootState_subState) {
        case Verrin::state_0:
        {
            state_0_serializeStates(aomsState);
        }
        break;
        case Verrin::state_1:
        {
            state_1_serializeStates(aomsState);
        }
        break;
        case Verrin::state_2:
        {
            state_2_serializeStates(aomsState);
        }
        break;
        case Verrin::state_3:
        {
            state_3_serializeStates(aomsState);
        }
        break;
        case Verrin::state_4:
        {
            state_4_serializeStates(aomsState);
        }
        break;
        case Verrin::state_7:
        {
            state_7_serializeStates(aomsState);
        }
        break;
        case Verrin::state_8:
        {
            state_8_serializeStates(aomsState);
        }
        break;
        case Verrin::state_9:
        {
            state_9_serializeStates(aomsState);
        }
        break;
        case Verrin::state_10:
        {
            state_10_serializeStates(aomsState);
        }
        break;
        default:
            break;
    }
}

void OMAnimatedVerrin::state_9_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_9");
}

void OMAnimatedVerrin::state_8_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_8");
}

void OMAnimatedVerrin::state_7_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_7");
}

void OMAnimatedVerrin::state_4_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_4");
}

void OMAnimatedVerrin::state_3_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_3");
}

void OMAnimatedVerrin::state_2_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_2");
}

void OMAnimatedVerrin::state_10_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_10");
}

void OMAnimatedVerrin::state_1_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_1");
}

void OMAnimatedVerrin::state_0_serializeStates(AOMSState* aomsState) const {
    aomsState->addState("ROOT.state_0");
}
//#]

IMPLEMENT_REACTIVE_META_P(Verrin, _DESIGN, _DESIGN, false, OMAnimatedVerrin)
#endif // _OMINSTRUMENT

/*********************************************************************
	File Path	: ExeReel\animConfig\Verrin.cpp
*********************************************************************/
